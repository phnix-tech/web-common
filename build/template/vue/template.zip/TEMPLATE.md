# 准备工作

+ 新建项目仓库
+ 从`web-common`下`build/template`中复制项目模板文件解压到仓库中
+ 根据以下提示修改相应信息
+ 配置`web-common`依赖，如果是svn仓库为了避免snv外部依赖默认抓取最新版可能出现依赖升级导致的非预期break change，请设置特定版本依赖
+ npm install
+ npm run dev
+ npm run build
+ 设置排除，如果是git仓库请忽略这一步，如果是svn仓库设置排除（`./build/lint`，`./node_modules`，`./dist`）

<hr/>

# 修改提示

## package.json
1. line2: 包名
2. line4: 描述
3. line5: 作者

## README.md
1. line1: 名字
2. line3: 说明

## build/config.js
1. line6: outputName，输出目录和打包名字

## .env
1. line19: PROXY_HOST，API代理主机

## public/index.html
1. line8: 网页title名字

## public/favicon.png
根据情况修改网站图标文件