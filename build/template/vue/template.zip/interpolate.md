# package.json
1. line2: 包名
2. line4: 描述
3. line5: 作者

# README.md
1. line1: 名字
2. line3: 说明

# build/config.js
1. line6: outputName，输出目录和打包名字

# .env
1. line19: PROXY_HOST，API代理主机

# public/index.html
1. line8: 网页title名字

# public/favicon.png
根据情况修改网站图标文件