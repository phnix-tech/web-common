process.env.PROXY_HOST = process.env.PROXY_HOST || "http://192.168.0.176:8080";
const vueCfg = require("./src/common/build/vue.config")();
module.exports = vueCfg;