const vueCfg = require("./src/common/build/vue/vue.config")({
  apiPrefix: process.env.API_PREFIX || undefined
});
module.exports = vueCfg;