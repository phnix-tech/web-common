// 本地调试，及时起效，比process.env环境变量优先级更高
// 去掉注释，设置对应值即可
// authentication、userInfo、identityID可以通过直接登录对应环境在浏览器开发者工具Application => Local Storage中获取
/* eslint-disable */
// window.___APP_authentication = "";
// window.___APP_userInfo = '{"userId":"4d15270e5093444281934551d88bc6bd","userNo":"ceshizhuanyong","orgNo":"3301960C27","orgName":"杭州祥茂医疗用品有限公司","orgCreditCode":"91330105060957517H","username":"测试3.0","password":null,"nickname":null,"email":"736276953@qq.com","telephone":"18512809869","address":"测试地址","fullPath":"/3.0测试企业/测试3.0","cardNumber":"533333333333333333","roles":["测试"]}';
// window.___APP_identityID = "";
// window.___APP_BASE_URL = "http://192.168.0.207:8000/api";
/* eslint-enable */
