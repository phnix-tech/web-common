// 本地调试，及时起效，比process.env环境变量优先级更高
// 设置对应值即可，`undefined`不设置值
const env = require("./common/src/env");
env.setValue("BASE_URL", undefined);