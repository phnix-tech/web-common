import HeaderAsideLayout from "@/layouts/HeaderAsideLayout";
import setting from "./routes/setting";

const routerConfig = [
  {
    path: "/",
    component: HeaderAsideLayout,
    children: [
      ...setting,
      {
        path: "/",
        component: () => import("@/pages/Dashboard")
      }
    ]
  },
  {
    path: "*",
    component: () => import("@/pages/NotFound")
  }
];

export default routerConfig;
