const {
  PUBLIC_PATH
} = require("../env");

/**
 *
 * @type {{publicPath: string}}
 */
module.exports = {
  publicPath: PUBLIC_PATH
};