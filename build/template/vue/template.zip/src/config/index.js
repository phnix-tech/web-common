const {
  publicPath
} = require("../env");

/**
 *
 * @type {{publicPath: string}}
 */
module.exports = {
  publicPath
};