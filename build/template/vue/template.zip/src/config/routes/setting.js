export default [
  {
    path: "/setting/param",
    component: () => import("@/pages/setting/Parameter"),
    name: "paramList",
    meta: {
      title: "参数表维护"
    }
  },
  {
    path: "/setting/updatepsd",
    component: () => import("@/pages/setting/UpdatePsd"),
    name: "updatePsd",
    meta: {
      title: "密码修改"
    }
  },
  {
    path: "/setting/dxpidconfig",
    component: () => import("@/pages/setting/Dxpid"),
    name: "dxpidconfig",
    meta: {
      title: "DXPID管理"
    }
  }
];
