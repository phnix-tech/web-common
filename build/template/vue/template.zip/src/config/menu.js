// 菜单配置
// asideMenuConfig：侧边导航配置

import setting from "./menus/setting";

const
  asideMenuConfig = [
    setting
  ];

export {asideMenuConfig};
