export default {
  url: "/setting",
  name: "系统设置",
  icon: "iconfont iconxitongguanli",
  children: [
    {
      url: "/setting/param",
      name: "参数表维护"
    },
    {
      url: "/setting/updatepsd",
      name: "密码修改"
    },
    {
      url: "/setting/dxpidconfig",
      name: "DXPID管理"
    }
  ]
};
