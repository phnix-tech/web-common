<template>
  <div :class="$style.container">
    <div :class="$style.wscnHttp404">
      <div :class="$style.pic404">
        <img
          src="../../assets/404.png"
          :class="$style.parent"
          alt="404"/>
        <img
          src="../../assets/404_cloud.png"
          :class="$style.child + ' ' + $style.left"
          alt="404"/>
        <img
          src="../../assets/404_cloud.png"
          :class="$style.child + ' ' + $style.mid"
          alt="404"/>
        <img
          src="../../assets/404_cloud.png"
          :class="$style.child + ' ' + $style.right"
          alt="404"/>
      </div>
      <div :class="$style.exception">
        <div :class="$style.headline">抱歉，你访问的页面不存在</div>
        <a
          href="/"
          :class="$style.returnHome">返回首页</a>
      </div>
    </div>
  </div>
</template>

<style src="./style.scss" lang="scss" module></style>