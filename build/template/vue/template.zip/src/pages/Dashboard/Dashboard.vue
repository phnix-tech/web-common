<template>
  <div :class="$style.container"/>
</template>

<style src="./style.scss" lang="scss" module></style>