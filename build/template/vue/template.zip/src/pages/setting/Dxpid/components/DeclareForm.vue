<template>
  <el-form ref="form" :model="form" label-width="110px">
    <el-row>
      <el-col :span="18">
        <el-col :span="8">
          <el-form-item label="单据类型" prop="messageType">
            <el-select v-model="form.messageType" placeholder="请选择">
              <el-option label="全部" :value="null"/>
              <el-option
                :key="item.value"
                v-for="item in typeList"
                :label="item.label"
                :value="item.value"/>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="14">
          <el-form-item label="录入时间" prop="startTime">
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="开始时间"
                value-format="yyyy-MM-dd"
                v-model="form.startTime"/>
            </el-col>
            <el-col :span="2" align="center">-</el-col>
            <el-col :span="11">
              <el-date-picker
                type="date"
                placeholder="结束时间"
                value-format="yyyy-MM-dd"
                v-model="form.endTime"/>
            </el-col>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :span="6" align="right">
        <el-button type="primary" @click="handleQuery" size="small">查询</el-button>
        <el-button @click="handleReset" size="small">重置</el-button>
      </el-col>
    </el-row>
  </el-form>
</template>

<script>
  export default {
    name: "DeclareForm",
    props: {
      list: Object,
      type: String,
      deletebookNo: Boolean,
      typeList: Array
    },
    data () {
      return {
        form: JSON.parse(JSON.stringify(this.list))
      };
    },
    methods: {
      // 重置
      handleReset () {
        this.$refs["form"].resetFields();
        this.form.endTime = null;
        this.$emit("onSelect", this.form);
      },
      // 表单查询
      handleQuery () {
        this.$emit("onSelect", this.form);
      }
    }
  };
</script>
