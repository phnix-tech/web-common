export default from "./Detail.vue";
