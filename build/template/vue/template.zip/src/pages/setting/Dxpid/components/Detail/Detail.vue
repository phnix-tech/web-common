<template>
  <div>
    <x-dialog
      v-if="DialogVisible"
      :title="title"
      :width="'60%'"
      @on-close="cancle">
      <div class="agreementDialogBody">
        <el-form
          ref="form"
          :model="form"
          :disabled="disabled"
          :rules="rules"
          label-width="110px">
          <el-row>
            <el-col :span="8">
              <el-form-item label="单据类型" prop="messageType">
                <el-select v-model="form.messageType" placeholder="请选择">
                  <el-option
                    :key="item.value"
                    v-for="item in typeList"
                    :label="item.label"
                    :value="item.value"/>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="DXPID" prop="dxpId">
                <el-input v-model="form.dxpId"/>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <template #footer>
        <el-button v-if="type !== 'look'" type="primary" @click="submit">确认</el-button>
        <el-button @click="cancle">取消</el-button>
      </template>
    </x-dialog>
  </div>
</template>

<script>
  import XDialog from "@/components/Dialog";
  export default {
    name: "Detail",
    components: {
      XDialog
    },
    props: {
      form: Object,
      type: String,
      typeList: Array
    },
    watch: {
      type: {
        handler (val) {
          if (val === "add") {
            this.title = "新增";
            this.disabled = false;
          } else if (val === "edit") {
            this.title = "修改";
            this.disabled = false;
          } else {
            this.title = "查看";
            this.disabled = true;
          }
        },
        immediate: true,
        deep: true
      }
    },
    data () {
      return {
        DialogVisible: false,
        disabled: false,
        title: "",
        rules: {
          messageType: [
            {required: true, message: "请选择单据类型", trigger: "change"}
          ],
          dxpId: [
            {required: true, message: "请输入DXPID", trigger: "blur"}
          ]
        }
      };
    },
    methods: {
      submit () {
        this.$refs["form"].validate(valid => {
          if (valid) {
            this.$emit("submit");
          } else {
            setTimeout(() => {
              this.$refs["form"].clearValidate();
            }, 3000);
          }
        });
      },
      cancle () {
        this.$refs.form.resetFields();
        this.DialogVisible = false;
      }
    }
  };
</script>
