<template>
  <div class="container">
    <x-form
      :list="form"
      :type-list="typeLIst"
      @onSelect="handleQuery"/>
    <el-row class="btn-pub">
      <el-button type="primary" @click="handleAdd" size="small">新增</el-button>
      <el-button type="primary" @click="handleDel" size="small">删除</el-button>
    </el-row>
    <x-table
      ref="table"
      :with-selection="true"
      :with-index="true"
      :columns="columns"
      @check-list="getCheckList"
      :page-list="pageList">
      <template #actions>
        <el-table-column
          align="center"
          label="操作"
          fixed="right"
          min-width="90"
          #default="{row}">
          <el-link @click="handleEdit(row)">修改</el-link><el-divider direction="vertical"/>
          <el-link @click="handleView(row)">查看</el-link><el-divider direction="vertical"/>
          <el-link @click="handleDel(row)">删除</el-link>
        </el-table-column>
      </template>
    </x-table>
    <x-detail
      ref="detail"
      @submit="handleSubmit"
      :type="type"
      :type-list="typeLIst"
      :form="detailForm"/>
  </div>
</template>

<script>
  import XForm from "./components/DeclareForm";
  import XTable from "@/components/Table";
  import service from "@/services/setting";
  import XDetail from "./components/Detail";

  const initDetailForm = {
    messageType: "",
    dxpId: ""
  };
  export default {
    name: "Dxpid",
    components: {
      XForm,
      XTable,
      XDetail
    },
    data () {
      return {
        checkList: [],
        detailForm: {...initDetailForm},
        // 单据类型
        typeLIst: [],
        // add; edit; look
        type: "add",
        form: {
          messageType: null,
          startTime: null,
          endTime: null
        }
      };
    },
    created () {
      service.messageSelect().then(res => {
        this.typeLIst = res.map(item => ({label: item.messageName, value: item.messageType}));
      });
    },
    methods: {
      // 获取勾选项
      getCheckList (arr) {
        this.checkList = [];
        if (arr.length > 0) {
          arr.forEach(item => {
            this.checkList.push(item.id);
          });
        }
      },
      // 详情新增修改提交
      handleSubmit () {
        const item = this.typeLIst.find(item => item.value === this.detailForm.messageType);
        if (this.type === "add") {
          service.messageAddDxp({...this.detailForm, messageName: item.label}).then(() => {
            this.$refs.table.pageLists();
            this.$refs.detail.DialogVisible = false;
            this.detailForm = {...initDetailForm};
          });
        } else {
          service.messageEditDxp({...this.detailForm, messageName: item.label}).then(() => {
            this.$refs.table.pageLists();
            this.$refs.detail.DialogVisible = false;
            this.detailForm = {...initDetailForm};
          });
        }
      },
      // 表单查询
      handleQuery (obj) {
        this.form = obj;
        this.$refs.table.pageLists();
      },
      // 新增
      handleAdd () {
        this.type = "add";
        this.$refs.detail.DialogVisible = true;
      },
      // 查看
      handleView (row) {
        service.messageDxpInfo({id: row.id, version: row.version}).then(res => {
          this.detailForm = res;
          this.type = "look";
          this.$refs.detail.DialogVisible = true;
        });
      },
      // 修改
      handleEdit (row) {
        service.messageDxpInfo({id: row.id, version: row.version}).then(res => {
          this.detailForm = res;
          this.type = "edit";
          this.$refs.detail.DialogVisible = true;
        });
      },
      // 删除
      handleDel (row) {
        if (row.id) {
          this.checkList = [row.id];
        }
        if (this.checkList.length < 1) {
          this.waFn("请勾选需要删除的数据！");
          return;
        }
        this.deleteBtn(this.checkList, this.DelList);
      },
      DelList (ids) {
        this.loading = true;
        service.messageDelDxp(ids).then(() => {
          this.$refs.table.pageLists();
        }).finally(() => {
          this.loading = false;
        });
      },
      // 表头
      columns () {
        const _this = this;
        return [
          {
            label: "单据类型",
            align: "center",
            minWidth: 100,
            formatter (row) {
              const label = _this.typeLIst.find(item => item.value === row.messageType);
              return label ? label.label : "";
            }
          },
          {
            label: "DXPID",
            align: "center",
            minWidth: 100,
            formatter (row) {
              return row.dxpId;
            }
          },
          {
            label: "录入时间",
            align: "center",
            minWidth: 100,
            formatter (row) {
              return row.createTime;
            }
          }
        ];
      },
      // 获取table数据
      async pageList (pageParams) {
        const data = await service.messageListPage({
          ...pageParams,
          ...this.form
        });
        return {
          tableData: data.body,
          total: data.page.total
        };
      }
    }
  };
</script>