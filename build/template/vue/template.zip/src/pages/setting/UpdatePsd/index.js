export default from "./UpdatePsd";
