<template>
  <div :class="$style.container" v-loading="loading">
    <el-form
      :model="form"
      ref="form"
      :rules="rules"
      label-width="80px">
      <el-row type="flex" justify="center">
        <el-col :span="8">
          <el-form-item
            label="原密码"
            prop="oldPassword">
            <el-input v-model.trim="form.oldPassword"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row type="flex" justify="center">
        <el-col :span="8">
          <el-form-item
            label="新密码"
            prop="newPassword">
            <el-input v-model.trim="form.newPassword"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row type="flex" justify="center">
        <el-col :span="8">
          <el-form-item
            label="确认密码"
            prop="checkPass">
            <el-input v-model.trim="form.checkPass"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row type="flex" justify="center">
        <el-col :span="8">
          <el-row type="flex" justify="center">
            <el-button type="primary" @click="handleSubmit">提交</el-button>
            <el-button @click="handleCancel">取消</el-button>
          </el-row>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
  import service from "@/services/setting";
  import loginservice from "@/services/login";

  export default {
    name: "UpdatePsd",
    data () {
      const validatePass2 = (rule, value, callback) => {
        if (value === "") {
          callback(new Error("请再次输入密码"));
        } else if (value !== this.form.newPassword) {
          callback(new Error("两次输入密码不一致!"));
        } else {
          callback();
        }
      };
      return {
        loading: false,
        form: {
          oldPassword: "",
          newPassword: "",
          checkPass: "",
          accessToken: localStorage.getItem("authentication")
        },
        rules: {
          oldPassword: [{required: true, message: "请输入原密码"}],
          newPassword: [{required: true, message: "请输入新密码"}],
          checkPass: [{required: true, validator: validatePass2}]
        }
      };
    },
    methods: {
      handleSubmit () {
        this.$refs["form"].validate(valid => {
          if (valid) {
            this.loading = true;
            service.editPsd(this.form).then(() => {
              // 修改成功后退出登录
              loginservice.logout().catch(() => {
                this.$message({
                  message: "退出登陆成功，即将跳转至登陆系统",
                  showClose: true
                });
              });
            }).finally(() => {
              this.loading = false;
            });
            return true;
          }
          return false;
        });
      },
      handleCancel () {
        this.$refs["form"].resetFields();
      }
    }
  };
</script>

<style lang="scss" src="./style.scss" module/>
