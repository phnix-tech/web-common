<template>
  <div :class="$style.container">
    <el-row>
      <el-col :span="8">
        <el-card>
          <template #header>
            <el-row type="flex" align="middle">
              <el-input
                placeholder="可输入关键字模糊查找"
                suffix-icon="el-icon-arrow-down"
                v-model="param"
                @input="handleChgParam"/>
            </el-row>
          </template>
          <div
            v-for="option in options"
            :key="option.value">
            <el-button :class="$style.directory" @click="handleSelectParam(option)">
              {{ option.label }}
            </el-button>
          </div>
        </el-card>
      </el-col>
      <el-col :span="16">
        <div
          v-if="selectedParam"
          :class="$style.rgtBox">
          <span><i class="el-icon-arrow-right"/>{{ selectedParam.label }}</span>
          <el-row>
            <el-col :span="8">
              <el-form :model="form" @submit.native.prevent>
                <el-form-item>
                  <el-input v-model="form.keyWord" @keyup.enter.native="onSearch" placeholder="请输入关键字查询"/>
                </el-form-item>
              </el-form>
            </el-col>
            <el-col :span="8" :offset="1">
              <el-button class="searchBtn" type="primary" @click="onSearch">查询</el-button>
            </el-col>
          </el-row>
          <wrapped-table
            ref="table"
            :cell-style="cellStyle"
            :with-index="true"
            :columns="columns"
            :page-list="pageList"
            :row-key="row => row.code"/>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {default as WrappedTable} from "@/components/Table";
  import service from "@/services/setting";

  function lblFn () {
    return {
      1: "关区全称",
      2: "中文名称",
      3: "商品分类",
      4: "货币名称",
      5: "外汇折算率",
      6: "计量单位",
      7: "用途",
      8: "包装种类",
      9: "运输工具类型",
      10: "运输方式",
      11: "监管证件名称",
      12: "监管方式",
      13: "指运港口"
    }[this.value];
  }

  function thirdCol () {
    return {
      1: "关区简称",
      2: "国家简称",
      4: "货币代码"
    }[this.value];
  }

  function thirdColName () {
    return {
      1: "shorterName",
      2: "shorterName",
      4: "symbol"
    }[this.value];
  }

  const options = [
    {
      value: 1,
      label: "关区代码表"
    },
    {
      value: 2,
      label: "国别代码表"
    },
    {
      value: 3,
      label: "商品综合分类表（涉证涉税商品检查）"
    },
    {
      value: 4,
      label: "币制代码表"
    },
    {
      value: 5,
      label: "外汇折算率表"
    },
    {
      value: 6,
      label: "计量单位代码表"
    },
    {
      value: 7,
      label: "用途代码表"
    },
    {
      value: 8,
      label: "包装种类代码表"
    },
    {
      value: 9,
      label: "运输工具类型代码表"
    },
    {
      value: 10,
      label: "运输方式代码表"
    },
    {
      value: 11,
      label: "监管证件名称代码表"
    },
    {
      value: 12,
      label: "监管方式代码表"
    },
    {
      value: 13,
      label: "指运港口代码表"
    }
  ].map(opt => {
    opt.lblFn = lblFn;
    opt.thirdCol = thirdCol;
    opt.thirdColName = thirdColName;
    return opt;
  });

  function columns (selectedParam) {
    return [
      {
        label: selectedParam.lblFn(),
        align: "center",
        formatter (param) {
          return param.name;
        }
      },
      {
        label: "代码",
        align: "center",
        formatter (param) {
          return param.code;
        }
      }
    ];
  }

  function columnsThree (selectedParam) {
    return [
      {
        label: selectedParam.lblFn(),
        align: "center",
        formatter (param) {
          return param.name;
        }
      },
      {
        label: "代码",
        align: "center",
        formatter (param) {
          return param.code;
        }
      },
      {
        label: selectedParam.thirdCol(),
        align: "center",
        formatter (param) {
          return param[selectedParam.thirdColName()];
        }
      }
    ];
  }

  // 外汇折算率
  function columnsExchrate () {
    return [
      {
        label: "代码",
        align: "center",
        formatter (param) {
          return param.code;
        }
      },
      {
        label: "汇率启用日期",
        align: "center",
        formatter (param) {
          return param.beginDate;
        }
      },
      {
        label: "汇率截止日期",
        align: "center",
        formatter (param) {
          return param.endDate;
        }
      },
      {
        label: "统计用人民币折算率",
        align: "center",
        formatter (param) {
          return param.rmbRate;
        }
      },
      {
        label: "统计用美元折算率",
        align: "center",
        formatter (param) {
          return param.usdRate;
        }
      },
      {
        label: "央行人民币折算率",
        align: "center",
        formatter (param) {
          return param.todayRate;
        }
      }
    ];
  }
  // 商品分类
  function columnsComplex () {
    return [
      {
        label: "商品名称",
        align: "center",
        formatter (param) {
          return param.gname;
        }
      },
      {
        label: "商品编号",
        align: "center",
        formatter (param) {
          return param.codeTS;
        }
      },
      {
        label: "临时减免标志",
        align: "center",
        formatter (param) {
          return param.lsjmFlag;
        }
      },
      {
        label: "生效日期",
        align: "center",
        formatter (param) {
          return param.beginDate;
        }
      },
      {
        label: "截止日期",
        align: "center",
        formatter (param) {
          return param.endDate;
        }
      },
      {
        label: "第一计量单位",
        align: "center",
        formatter (param) {
          return param.unit1;
        }
      },
      {
        label: "第二计量单位",
        align: "center",
        formatter (param) {
          return param.unit2;
        }
      },
      {
        label: "监管要求",
        align: "center",
        formatter (param) {
          return param.controlMark;
        }
      }
    ];
  }

  // 运输工具
  function columnsTransportTool () {
    return [
      {
        label: "类型描述",
        align: "center",
        formatter (param) {
          return param.veTypeNote;
        }
      },
      {
        label: "运输工具类型",
        align: "center",
        formatter (param) {
          return param.veType;
        }
      },
      {
        label: "运输方式",
        align: "center",
        formatter (param) {
          return param.veMode;
        }
      }
    ];
  }

  // 监管证件

  function columnsLicense () {
    return [
      {
        label: "监管证件名称",
        align: "center",
        formatter (param) {
          return param.docuName;
        }
      },
      {
        label: "代码",
        align: "center",
        formatter (param) {
          return param.docuCode;
        }
      },
      {
        label: "监管证件简称",
        align: "center",
        formatter (param) {
          return param.abbrName;
        }
      }
    ];
  }

  export default {
    name: "Parameter",
    components: {
      WrappedTable
    },
    data () {
      return {
        param: "",
        selectedParam: options[0],
        options: [...options],
        form: {
          keyWord: ""
        }
      };
    },
    methods: {
      handleChgParam (keyword) {
        this.param = keyword;
        this.options = options.filter(opt => {
          return opt.label.indexOf(this.param) !== -1;
        });
      },
      handleSelectParam (param) {
        this.form.keyWord = "";
        this.selectedParam = param;
        this.$refs.table.handlePageChg(1);
      },
      columns () {
        if ([1, 2, 4].indexOf(this.selectedParam.value) > -1) {
          // 三列
          return columnsThree(this.selectedParam);
        } else if (this.selectedParam.value === 5) {
          // 外汇折算率
          return columnsExchrate();
        } else if (this.selectedParam.value === 3) {
          // 商品分类
          return columnsComplex();
        } else if (this.selectedParam.value === 9) {
          // 运输工具
          return columnsTransportTool();
        } else if (this.selectedParam.value === 11) {
          // 监管证件
          return columnsLicense();
        }
        // 两列
        return columns(this.selectedParam);
      },
      onSearch () {
        this.$refs.table.pageLists();
      },
      pageList (pageParams) {
        return service.listPage({
          ...pageParams,
          ...this.form
        }, this.selectedParam.value);
      },
      // 商品分类黑名单名称标红
      cellStyle ({row, columnIndex}) {
        let style;
        if (columnIndex === 1 && row.status === 1) {
          style = "color: #f00";
        }
        return style;
      }
    }
  };
</script>

<style lang="scss" module src="./style.scss"></style>
