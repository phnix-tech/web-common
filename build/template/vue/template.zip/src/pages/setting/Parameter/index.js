import Parameter from "./Parameter";

export default Parameter;