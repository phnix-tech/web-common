export default from "./Table";
