<template>
  <div
    ref="scrollContainer"
    :class="$style.scrollContainer"
    @wheel.prevent="handleScroll">
    <div
      ref="scrollWrapper"
      :style="{top: top + 'px'}"
      :class="$style.scrollWrapper">
      <slot/>
    </div>
  </div>
</template>

<script>
  const delta = 40;

  export default {
    name: "ScrollBar",
    data () {
      return {
        top: 0
      };
    },
    methods: {
      handleScroll (e) {
        const
          eventDelta = e.wheelDelta || -e.deltaY * 3,
          $container = this.$refs.scrollContainer,
          $containerHeight = parseInt($container.offsetHeight, 10),
          $wrapper = this.$refs.scrollWrapper,
          $wrapperHeight = parseInt($wrapper.offsetHeight, 10);

        if (eventDelta > 0) {
          this.top = Math.min(0, this.top + eventDelta);
        } else if ($containerHeight - delta < $wrapperHeight) {
          if (this.top >= -(delta + ($wrapperHeight - $containerHeight))) {
            this.top = Math.max(
              this.top + eventDelta,
              $containerHeight - $wrapperHeight - delta
            );
          }
        } else {
          this.top = 0;
        }
      }
    }
  };
</script>

<style lang="scss" module src="./style.scss"/>
