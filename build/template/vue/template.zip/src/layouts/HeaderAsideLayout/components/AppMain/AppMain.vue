<template>
  <section :class="$style.appMain">
    <div
      v-if="$route.path !== '/'"
      :class="$style.breadcrumbBox">
      <el-breadcrumb
        separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{path: '/'}">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{ $route.meta.title }}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div :class="$style.contentBox">
      <router-view/>
    </div>
  </section>
</template>

<script>
  export default {
    name: "AppMain"
  };
</script>

<style lang="scss" module src="./style.scss"/>
