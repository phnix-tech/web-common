<template>
  <scroll-bar
    :class="{
      [$style.sidebarContainer]: true,
      [$style.isContraction]: collapse
    }">
    <el-menu
      :show-timeout="200"
      mode="vertical"
      background-color="#f5f9ff"
      :collapse="collapse"
      :default-active="$route.path"
      router
      :unique-opened="true"
      text-color="#fff"
      active-text-color="#3c568f">
      <template v-for="item in asideMenuConfig">
        <el-menu-item
          v-if="!item.children"
          :key="item.url"
          :index="item.url"
          class="no-child-menu">
          <i
            v-if="menuIcon[item.url]"
            :class="menuIcon[item.url]"/>
          <template
            v-if="item.name"
            #title>
            <span>{{ item.name }}</span>
          </template>
        </el-menu-item>

        <el-submenu
          v-else
          :index="item.url"
          :key="item.name">
          <template #title>
            <div>
              <i
                v-if="menuIcon[item.url]"
                :class="menuIcon[item.url]"/>
              <span v-if="item && item.name">
                {{ item.name }}
              </span>
            </div>
          </template>
          <template
            v-for="child in item.children">
            <router-link
              :to="child.url"
              :key="child.name">
              <el-menu-item :index="child.url">
                <template
                  v-if="child && child.name"
                  #title>
                  <span>{{ child.name }}</span>
                </template>
              </el-menu-item>
            </router-link>
          </template>
        </el-submenu>
      </template>
    </el-menu>
  </scroll-bar>
</template>

<script>
  import service from "@/services/login";
  import menuicon from "@/config/menuicon.json";
  import {asideMenuConfig} from "@/config/menu";
  import ScrollBar from "../../components/ScrollBar";

  export default {
    name: "SideBar",
    components: {ScrollBar},
    props: {
      collapse: Boolean || true
    },
    data () {
      return {
        asideMenuConfig: [],
        menuIcon: menuicon,
        hasAuth: true
      };
    },
    methods: {
      getPermissions () {
        return service.getPermissions({
          type: 0,
          sequence: ""
        }).then(data => {
          if (!this.hasAuth) {
            data[0].children = [data[0].children[0]];
            this.asideMenuConfig = [data[0]];
          } else {
            this.asideMenuConfig = data;
          }
        });
      }
    },
    created () {
      if (
        !this.common.getUrlKey("code") ||
        localStorage.getItem("authentication")
      ) {
        this.getPermissions();
      }
      const host = window.location.host;
      if (
        host.indexOf("localhost") !== -1
      ) {
        this.asideMenuConfig = asideMenuConfig;
      }
    },
    watch: {
      "$store.state.authentication" () {
        this.getPermissions();
      }
    }
  };
</script>

<style lang="scss" module src="./style.scss"/>
