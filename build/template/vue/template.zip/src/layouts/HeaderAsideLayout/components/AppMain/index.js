export default from "./AppMain";
