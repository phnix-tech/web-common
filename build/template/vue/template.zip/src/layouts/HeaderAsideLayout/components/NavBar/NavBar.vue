<template>
  <div :class="$style.navbar">
    <div :class="$style.userProfileContainer">
      <div :class="$style.userProfileContent">
        <div :class="$style.menuIcons">
          <span :class="$style.menuIcon"/>
          <el-menu mode="horizontal">
            <el-submenu index="1">
              <el-menu-item @click="logout">
                <span :class="$style.menuIcon">
                  <i class="iconfont icontuichu2"/>&nbsp;&nbsp;退出
                </span>
              </el-menu-item>
            </el-submenu>
          </el-menu>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import service from "@/services/login";

  export default {
    name: "NavBar",
    data () {
      return {
        name: null
      };
    },
    props: {
      username: {
        type: String
      }
    },
    methods: {
      logout () {
        service.logout().catch(() => {
          this.$message({
            message: "退出登陆成功，即将跳转至登陆系统",
            showClose: true
          });
        });
      }
    }
  };
</script>

<style lang="scss" module src="./style.scss"/>