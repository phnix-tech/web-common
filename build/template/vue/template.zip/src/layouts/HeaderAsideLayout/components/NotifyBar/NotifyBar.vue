<template>
  <div :class="$style.container">
    海关关闸站  高級督察 XXX，您有
    <div :class="$style.notifyList">
      <div :class="$style.item">
        • 待處理案件 <span :class="$style.countBox">(<b>1</b>)</span>
      </div>
      <div :class="$style.item">
        • 急件 <span :class="$style.countBox">(<b>10</b>)</span>
      </div>
      <div :class="$style.item">
        • 待處理扣押物 <span :class="$style.countBox">(<b>10</b>)</span>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "NotifyBar",
    props: {
      username: {
        type: String
      }
    }
  };
</script>

<style lang="scss" module src="./style.scss"/>
