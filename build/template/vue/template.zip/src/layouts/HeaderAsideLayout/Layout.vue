<template>
  <div
    :class="{
      [$style.appWrapper]: true
    }">
    <header :class="$style.mainHead">
      <div :class="$style.headTop">
        <i
          style="display: none;"
          class="iconfont icongengduo1"
          :class="[$style.mr, {[$style.active]: isFlip}]"
          @click="toggleSideBar"/>
        <span :class="$style.logo"/>
        <div :class="$style.siteName">
          澳門海關綜合管理系統
          <b>Macao Customs Integrated Management System</b>
        </div>
      </div>
      <nav-bar :username="username"/>
    </header>
    <template v-if="isShowMa">
      <side-bar :collapse="isContraction"/>
    </template>
    <div
      :class="{
        [$style.mainContainer]: true,
        [$style.mf]: !isShowMa,
        [$style.isContraction]: isContraction
      }">
      <app-main/>
    </div>
  </div>
</template>

<script>
  import env from "@/env";
  import {AppMain, NavBar, SideBar} from "./components";
  import service from "@/services/login";

  (function () {
    // 前端设置session登录参数用于连接其他环境，如本地代理到测试环境
    // 环境变量设置参考.env文件
    const
      authentication = env.authentication,
      userInfo = env.userInfo,
      identityID = env.identityID;

    if (authentication) {
      localStorage.setItem("authentication", authentication);
    }
    if (userInfo) {
      localStorage.setItem("userInfo", userInfo);
    }
    if (identityID) {
      localStorage.setItem("identityID", identityID);
    }
  }());

  export default {
    name: "Layout",
    components: {
      NavBar,
      SideBar,
      AppMain
    },
    data () {
      return {
        isContraction: false,
        isFlip: false,
        username: ""
      };
    },
    computed: {
      isShowMa () {
        return this.$store.state.changeLeftNav !== 0;
      }
    },
    methods: {
      logout () {
        service.logout().catch(() => {
          this.$message({
            message: "退出登陆成功，即将跳转至登陆系统",
            showClose: true
          });
        });
      },
      toggleSideBar () {
        this.isContraction = !this.isContraction;
        this.isFlip = !this.isFlip;
      },
      login (params) {
        // 根据4A登陆返回参数code、state调用登陆接口获取用户信息
        service.login(params).then(data => {
          const
            {
              originTokenValue: authentication,
              jti: identityID,
              userInfo
            } = data;

          this.$store.state.authentication = authentication;
          localStorage.setItem("authentication", authentication);
          localStorage.setItem("identityID", identityID);
          localStorage.setItem("userInfo", JSON.stringify(userInfo));
          this.username = userInfo.username;
        });
      }
    },
    mounted () {
      const code = this.common.getUrlKey("code");
      const state = this.common.getUrlKey("state");
      if (
        code &&
        !localStorage.getItem("authentication")
      ) {
        this.login({code, state});
      }
    }
  };
</script>

<style lang="scss" module src="./style.scss"/>
