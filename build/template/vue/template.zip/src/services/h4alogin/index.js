import http from "@/utils/http";

export default {
  getAuth (params) {
    return http.get({
      url: "/auth/info",
      data: params,
      errmsg: false
    });
  },
  logout () {
    return http.get({
      url: "/auth/logout"
    });
  },
  getPermissions () {
    return http.get({
      url: "/auth/menus",
      resp: true
    });
  }
};
