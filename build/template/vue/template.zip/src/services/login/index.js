import http from "@/utils/http";

export default {
  login (params) {
    return http.get({
      url: "/authority/login",
      data: params
    });
  },
  logout () {
    return http.post({
      url: "/authority/ssoLogout",
      errmsg: false
    });
  },
  // 获取菜单 /api/auth/menus  /authority/getMenuTree
  getPermissions (params) {
    return http.get({
      url: "/authority/getMenuTree",
      data: params
    });
  }
};
