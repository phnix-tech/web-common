import http from "@/utils/http";

export default {
  // 参数表分页与查询
  listPage (params, index) {
    const urlObj = {
      // 关区代码
      1: "/system/customs/listPage",
      // 国别代码
      2: "/system/country/listPage",
      // 商品综合分类
      3: "/system/complex/listPage",
      // 币制代码
      4: "/system/currency/listPage",
      // 外汇折算率表
      5: "/system/exchrate/listPage",
      // 计量单位代码
      6: "/system/unit/listPage",
      // 用途代码表
      7: "/system/used/listPage",
      // 包装种类
      8: "/system/wrap/listPage",
      // 运输工具类型
      9: "/system/transportTool/listPage",
      // 运输方式
      10: "/system/transport/listPage",
      // 监管证件名称
      11: "/system/licensedocu/listPage",
      // 监管方式
      12: "/system/trade/listPage",
      // 港口
      13: "/system/port/listPage"
    };

    if (!urlObj[index]) {
      throw new Error(`index ${index} not supported`);
    }

    return http.post({
      url: urlObj[index],
      data: params
    }).then(data => {
      return {
        tableData: data.body,
        total: data.page.total
      };
    });
  }
};
