import http from "@/utils/http";
import codetable from "@/services/codetable";

export default {
  // 参数表分页与查询
  listPage: codetable.listPage,
  updateStatus (params, index) {
    const urlObj = {
      1: "/customs/status",
      2: "/country/status",
      3: "商品分类",
      4: "/currency/status",
      5: "限制商品",
      6: "包裹限制",
      7: "/trade/status",
      8: "/container/status"
    };
    return http.get({
      url: urlObj[index],
      data: params,
      msg: true
    });
  },
  // 修改密码
  editPsd (params) {
    return http.post({
      url: "/system/user/updatePassword",
      data: params,
      msg: true
    });
  },
  // 配置信息
  getConfig () {
    return http.get({
      url: "/system/config/getConfig"
    });
  },
  saveConfig (params) {
    return http.post({
      url: "/system/config/save",
      data: params,
      msg: true
    });
  },
  // 报文类型下拉框
  messageSelect () {
    return http.get({
      url: "/system/message/select"
    });
  },
  // dxp分页与查询
  messageListPage (params) {
    return http.post({
      url: "/system/message/listPage",
      data: params
    });
  },
  // 添加dxpId
  messageAddDxp (params) {
    return http.post({
      url: "/system/message/addDxp",
      data: params,
      msg: true
    });
  },
  // 编辑dxpId
  messageEditDxp (params) {
    return http.post({
      url: "/system/message/editDxp",
      data: params,
      msg: true
    });
  },
  // 删除dxpId
  messageDelDxp (params) {
    return http.post({
      url: "/system/message/delDxp",
      data: params,
      msg: true
    });
  },
  // 获取dxpId
  messageDxpInfo (params) {
    return http.post({
      url: "/system/message/dxpInfo",
      data: params
    });
  }
};
