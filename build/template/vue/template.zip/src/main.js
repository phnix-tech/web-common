// ES6 polyfill mainly for Promise.prototype.finally
import "core-js/stable";
import "./debug";
import Vue from "vue";
import "./ElementUI";
import "normalize.css/normalize.css";
import "@/styles/index.scss";
import App from "./App.vue";
import publicJs from "./utils/public";
import router from "./router";
import store from "@/stores";
import filters from "@/filters";

Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key]);
});

// this.common的形式调用
Vue.prototype.common = publicJs.pubFunc;

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
