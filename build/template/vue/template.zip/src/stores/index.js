import Vue from "vue";
import Vuex from "vuex";
import createPersistedState from "vuex-persistedstate";

Vue.use(Vuex);

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",
  state: {
    authentication: "",
    // 左侧菜单切换
    changeLeftNav: 1
  },
  getters: {

  },
  modules: {

  },
  mutations: {
    changeLeftNav (state, flag) {
      state.changeLeftNav = flag;
    }
  },
  plugins: [
    createPersistedState({
      storage: window.sessionStorage,
      reducer (val) {
        return {
          ...val
        };
      }
    })
  ]
});
