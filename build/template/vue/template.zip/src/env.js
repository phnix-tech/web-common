const env = require("./common/src/env");
const PUBLIC_PATH = env.PUBLIC_PATH || "/";
const BASE_URL = env.BASE_URL || "/api";

// 用户相关配置
const authentication = env.getValue("authentication");
const userInfo = env.getValue("userInfo");
const identityID = env.getValue("identityID");

module.exports = {
  PUBLIC_PATH,
  BASE_URL,
  authentication,
  userInfo,
  identityID
};