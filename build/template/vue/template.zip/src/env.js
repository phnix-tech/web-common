const env = require("./common/src/env");
const publicPath = env.publicPath || "/";
const baseURL = env.baseURL || "/api";

// 用户相关配置
const authentication = env.getValue("authentication");
const userInfo = env.getValue("userInfo");
const identityID = env.getValue("identityID");

module.exports = {
  publicPath,
  baseURL,
  authentication,
  userInfo,
  identityID
};