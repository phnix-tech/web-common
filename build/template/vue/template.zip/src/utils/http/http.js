import axios from "axios";
import {Message as message} from "element-ui";
import env from "@/env";
import axioscfg from "./axioscfg";

axioscfg.config(axios);

function isObj (obj) {
  return Object.prototype.toString.call(obj) === "[object Object]";
}

function erFn (msg) {
  return message.error({
    message: msg,
    showClose: true
  });
}

function suFn (msg) {
  return message.success({
    message: msg,
    showClose: true
  });
}

const BASE_URL = env.BASE_URL;

/**
 *
 * @param {'get'|'post'|'put'|'delete'|'patch'} method
 * @param {string} url
 * @param {object} data
 * @param {boolean} msg 2xx状态下是否提示后端返回msg，默认值false
 * @param {boolean} errmsg 非2xx状态下是否自动提示后端错误消息，默认值true
 * @param {boolean} resp 是否返回axios resp.data和resp
 * 注意：由于promise resolve只能传递一个参数，请用数组解构接受多个参数
 * @param {number} timeout 请求超时时间, 默认10s
 * @returns {Promise<*>}
 */
function creator (
  {
    method = "get",
    url,
    data,
    msg = false,
    errmsg = true,
    resp = false,
    timeout = 10000
  } = {}
) {
  // cancel function
  // 为了简便，我们将cancel设置于data对象中
  const cancel = data && data.cancel;
  let cancelToken;
  if (typeof cancel === "function") {
    delete data.cancel;
    cancelToken = new axios.CancelToken(c => {
      cancel(c);
    });
  }

  const
    // https://github.com/axios/axios
    config = {
      timeout,
      cancelToken,
      baseURL: BASE_URL
    },
    instance = axios.create();

  axioscfg.addHeaders(instance);
  axioscfg.addTimestamp(instance);
  axioscfg.addLoginCheck(instance);

  method = method.toUpperCase();
  config.method = method.toLowerCase();
  config.url = url;

  // 统一数据参数data
  if (data) {
    if (method === "PUT" ||
      method === "POST" ||
      method === "PATCH") {
      config.data = data;
    } else {
      // get request query params
      config.params = data;
    }
  }

  const
    withMsg = msg,
    withData = resp;

  return new Promise((resolve, reject) => {
    instance.request(config)
      .then(resp => {
        if (!resp) {
          return;
        }
        // @see http://192.168.0.241/article/1573794164460
        let
          status = resp.status,
          data = resp.data;
        const msg = data.msg;

        if (status === 200) {
          // status二次处理
          status = data.status;
          data = data.data;

          // 兼容response.data直接为json数据
          if (status === undefined) {
            status = 200;
            if (data === undefined) {
              data = resp.data;
            }
          }

          if (status === 200) {
            // 直接传递data作为Promise的接收值
            // 统一处理data让service层直接得到json数据
            if (isObj(data) &&
              Object.keys(data).length === 1 &&
              data.hasOwnProperty("body")
            ) {
              data = data.body;
            }

            if (msg && withMsg) {
              suFn(msg);
            }

            if (!withData) {
              resolve(data, resp.data, resp);
            } else {
              resolve([data, resp.data, resp]);
            }

            return;
          }
        }

        if (errmsg && msg) {
          erFn(msg);
        }
        // 此处需要加上以下代码，因为页面上还需要根据返回的值做后续处理
        reject(resp);
      })
      .catch(err => {
        let msg = err.message || JSON.stringify(err);
        // 重置请求超时默认文字
        if (err.code === "ECONNABORTED" &&
          msg.indexOf("timeout") !== -1) {
          msg = "请求超时";
        }

        // 手动cancel request
        if (!axios.isCancel(err)) {
          if (errmsg) {
            erFn(msg);
          }
          reject(err);
        }
      });
  });
}

/**
 * 将基于后端接口路径的绝对路径转换为带`baseURL`前缀的url路径
 * 注意第一个url必须为绝对路径，如果为相对路径也会将其转为绝对路径
 */
creator.resolveurl = function () {
  let url = BASE_URL;
  // 去除尾部斜线
  url = url.replace(/\/$/, "");

  [...arguments].forEach(arg => {
    // 加上头部斜线
    if (!/^\//.test(arg)) {
      arg = "/" + arg;
    }

    url += arg;
  });

  return url;
};

export {
  creator as HttpRequest
};
