import {HttpRequest} from "./http";
import http from "@/common/src/utils/http";

http.HttpRequest = HttpRequest;
export default http;