import addUrlTimestamp from "@/common/src/utils/http/addUrlTimestamp";

function addHeaders (axios) {
  return axios.interceptors.request.use(config => {
    // 添加全局请求头
    config.headers.common["Platform"] = "MPW";
    config.headers.common["Authentication"] = localStorage.getItem("authentication") || "default";
    config.headers.common["IdentityID"] = localStorage.getItem("identityID") || "default";

    return config;
  });
}

function addTimestamp (axios) {
  // Add request interceptor
  return axios.interceptors.request.use(config => {
    // add timestamp to url (GET method only) for disable cache
    if (
      config.method.toLowerCase() === "get" &&
      // assume _ param is timestamp param
      !/_=\d+/.test(config.url)
    ) {
      config.url = addUrlTimestamp(config.url);
    }

    return config;
  });
}

function addLoginCheck (axios) {
  // http request 响应拦截器
  // https://github.com/axios/axios#interceptors
  return axios.interceptors.response.use(
    resp => resp,
    error => {
      const resp = error.response;
      if (!resp) {
        return Promise.reject(error);
      }

      if (resp.status === 401) {
        localStorage.removeItem("authentication");
        localStorage.removeItem("identityID");
        localStorage.removeItem("userInfo");
        sessionStorage.removeItem("vuex");
        // 登录URL示例
        // http://192.168.0.253:8081/4a/oauth/authorize?response_type=code&logout_url=http://192.168.0.204/api//logout&redirect_uri=http://192.168.0.204:8082&client_id=eWTP&state=5DLqhC
        const loginUrl = resp.headers.location;

        // 后端目前不支持修改redirect_uri参数
        // const redirectUri = `${location.protocol}//${location.host}`;
        // if (loginUrl.indexOf("redirect_uri") !== -1) {
        //   loginUrl = loginUrl.replace(/(redirect_uri=)[^&]+/, `$1${redirectUri}`);
        // }
        location.href = loginUrl;
        return Promise.reject(error);
      }
      return Promise.reject(error);
    }
  );
}

let isConfigured = false;

/**
 * axios common config function, e.g. add timestamp in GET url
 * @param {object} axios - axios object
 * @see https://github.com/axios/axios
 */
function config (axios) {
  if (isConfigured) {
    return;
  }

  // set global config
  axios.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded;charset=utf-8";

  addHeaders(axios);
  addTimestamp(axios);
  addLoginCheck(axios);

  isConfigured = true;
}

export default {
  config,
  addTimestamp,
  addHeaders,
  addLoginCheck
};
