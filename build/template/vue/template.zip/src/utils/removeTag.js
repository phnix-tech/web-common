import store from "@/stores";
import router from "@/router";

const removeTag = route => {
  return store.dispatch("delVisitedViews", route)
    .then(views => {
      if (route.path !== router.currentRoute.path) {
        return Promise.resolve();
      }

      // 只有在关闭当前打开的标签页才会有影响
      // 选取路由数组中的最后一位
      const lastRoute = views.slice(-1)[0];
      if (!lastRoute) {
        return router.push("/");
      }

      const
        {
          path,
          query
        } = lastRoute;

      return router.push({
        path,
        query
      });
    });
};

export default removeTag;
