import {publicPath} from "../config";

/**
 * 将基于项目根路径的绝对路径转换为带`publicPath`前缀的url路径
 * 注意第一个url必须为绝对路径，如果为相对路径也会将其转为绝对路径
 */
export default function () {
  let url = publicPath;
  // 去除尾部斜线
  url = url.replace(/\/$/, "");

  [...arguments].forEach(arg => {
    // 加上头部斜线
    if (!/^\//.test(arg)) {
      arg = "/" + arg;
    }

    url += arg;
  });

  return url;
}
