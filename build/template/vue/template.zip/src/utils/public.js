import Vue from "vue";

// 成功提示
Vue.prototype.suFn = function (message) {
  return Vue.prototype.$message({
    showClose: true,
    message,
    type: "success",
    duration: 3000
  });
};

// 错误提示
Vue.prototype.erFn = function (message) {
  if (message === "" || message === null || message === undefined) {
    message = "Service error, please refresh and retry or contact administrator";
  }
  return Vue.prototype.$message({
    showClose: true,
    message,
    type: "error",
    duration: 3000
  });
};

// 警告提示
Vue.prototype.waFn = function (message) {
  return Vue.prototype.$message({
    showClose: true,
    message,
    type: "warning",
    duration: 3000
  });
};


Vue.prototype.confirmFn = function (msg, title, opts) {
  title = title || "确认";
  opts = opts || {};
  opts = {
    confirmButtonText: "是",
    cancelButtonText: "否",
    type: "warning",
    closeOnClickModal: false,
    ...opts
  };
  return Vue.prototype.$confirm(msg, title, opts);
};

// 刪除方法
Vue.prototype.deleteBtn = function (args, callback, msg) {
  msg = msg ? msg : "确定删除?";
  return Vue.prototype.confirmFn(msg, "删除")
    .then(() => {
      if (typeof callback === "function") {
        callback(args);
      }
    }).catch(() => {
      return;
    });
};

// 表格数据为空处理
Vue.prototype.fmtEmpty = function (row, column) {
  const obj = row[column.property];
  if (!obj) {
    return "-";
  }
  return obj;
};

const pubFunc = {
  // val 当前值 form 分页表单，callback 执行函数
  handleSizeChange (val, form, callback) {
    form.pageSize = val;
    if (callback) {
      callback();
    }
  },
  // 跳转到多少页
  handleCurrentChange (val, form, callback) {
    form.page = val;
    if (callback) {
      callback();
    }
  },
  // 表格序号
  indexMethod (index, page, pageSize) {
    return index + 1 + (page - 1) * pageSize;
  },
  // 获取url参数
  getUrlKey (name) {
    const
      // 构造一个含有目标参数的正则表达式对象
      reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"),
      // 匹配目标参数
      r = window.location.search.substr(1).match(reg);

    // 返回参数值
    if (r !== null) {
      return unescape(r[2]);
    }
    return null;
  }
};

export default {pubFunc};
