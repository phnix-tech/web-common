# mpw

> 澳门海关综合管理系统

# 项目规范

开发前请阅读[前端项目规范](http://192.168.0.241/article/1595902258821) 了解项目规范，按照团队约定规范开发。

# npm scripts

## dev/start

开发服务器构建

## build

生产环境构建

## clean

清除本地构建目录，比如dist、src/common

## lint

js和样式格式检查

## eslint

js格式检查

## stylelint

样式格式检查