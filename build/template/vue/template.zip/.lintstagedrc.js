/**
 * 注意：相对路径相对于npm项目根路径，而不是git根路径
 * @see https://github.com/okonet/lint-staged#configuration
 * OSX Source Tree git hooks没有起效？
 * @see https://stackoverflow.com/questions/17538460/using-git-pre-commit-hooks-in-context-of-github-client/33588294#33588294
 * PATH="/usr/local/bin:$PATH"
 */
module.exports = {
  "./src/**/*.{js,vue}": "eslint",
  "./src/**/*.{scss,less,vue}": "stylelint"
};