const cfg = require("gs-lint/stylelint/.stylelintrc");
module.exports = require("./src/common/build/stylelintrc")(cfg);