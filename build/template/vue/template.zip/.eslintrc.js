const dftCfg = require("gs-lint/eslint/.eslintrc");
const vueRules = require("gs-lint/eslint/eslint-vue")(dftCfg);

module.exports = require("./src/common/build/vue/eslintrc")(vueRules);