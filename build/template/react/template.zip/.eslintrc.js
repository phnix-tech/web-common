const dftCfg = require("gs-lint/eslint/.eslintrc");
const reactRules = require("gs-lint/eslint/eslint-react")(dftCfg);
module.exports = require("./src/common/build/react/eslintrc")(reactRules);