import "./debug";
import React from "react";
import ReactDOM from "react-dom";
import "./styles/index.scss";
import {getLocale} from "./utils/locale";
import LanguageProvider from "./components/LocaleProvider";
import RootStore from "@/components/RootStore";
import router from "./router";

const app = document.getElementById("app");
if (!app) {
  throw new Error("当前页面不存在 <div id=\"app\"></div> 节点.");
}

function Index () {
  return (
    <LanguageProvider locale={getLocale()}>
      <RootStore>
        {router()}
      </RootStore>
    </LanguageProvider>
  );
}

ReactDOM.render(<Index/>, app);