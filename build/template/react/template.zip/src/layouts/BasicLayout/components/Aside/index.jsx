import React, {useState, useEffect, useRef} from "react";
import {Link, withRouter} from "react-router-dom";
import {Nav} from "@alifd/next";
import stores from "@/stores/index";
import Auth from "@/components/Auth";
import Logo from "../Logo";
import {asideMenuConfig} from "@/config/menu";
import styles from "./index.module.scss";

const
  SubNav = Nav.SubNav,
  NavItem = Nav.Item;

/**
 * 根据权限决定是否渲染某个表单项
 * @param {object} item - 菜单项组件
 * @param {array} authorities - 菜单项允许权限数组
 * @return {object} 渲染的菜单项
 */
function renderAuthItem (item, authorities) {
  if (authorities) {
    return Auth({
      children: item,
      authorities,
      hidden: true
    });
  }

  return item;
}

/**
 * 二级导航
 */
function getSubMenuOrItem (item, index) {
  if (item.children && item.children.some(child => child.name)) {
    const childrenItems = getNavMenuItems(item.children);
    if (childrenItems && childrenItems.length > 0) {
      const subNav = (
        <SubNav
          key={index}
          icon={item.icon ? <img src={item.icon} alt=""/> : null}
          label={
            <span className="ice-menu-collapse-hide">
              {item.name}
            </span>
          }
        >
          {childrenItems}
        </SubNav>
      );

      return renderAuthItem(subNav, item.authorities);
    }
    return null;
  }

  const navItem = (
    <NavItem
      key={item.path}
      icon={item.path === "/home" ? <img src={item.icon} alt=""/> : null}>
      <Link to={item.path}>
        {item.name}
      </Link>
    </NavItem>
  );

  return renderAuthItem(navItem, item.authorities);
}

/**
 * 获取菜单项数据
 */
function getNavMenuItems (menusData) {
  if (!menusData) {
    return [];
  }

  return menusData
    .filter(item => item.name && !item.hideInMenu)
    .map((item, index) => {
      return getSubMenuOrItem(item, index);
    });
}

/**
 * 获取默认展开菜单项
 */
function getDefaultOpenKeys (location = {}, menuConfig) {
  const
    {pathname} = location,
    menus = getNavMenuItems(menuConfig);

  let openKeys = [];
  if (Array.isArray(menus)) {
    menuConfig.forEach((item, index) => {
      if (pathname.startsWith(item.path)) {
        openKeys = [`${index}`];
      }
    });
  }

  return openKeys;
}

const Aside = withRouter(props => {
  const expandAside = stores.useStore("expandAside"),
    [
      menuConfig
    ] = useState(asideMenuConfig),
    {collapse, toggle} = expandAside,

    {location} = props,
    userProfile = stores.useStore("userProfile");

  let {pathname} = location;
  if (pathname === "/warehouse/stock-in/print") {
    pathname = "/warehouse/stock-in";
  } else if (pathname === "/warehouse/stock-out/print") {
    pathname = "/warehouse/stock-out";
  }

  const
    defaultOpenKeys = getDefaultOpenKeys(location, menuConfig),
    [openKeys, setOpenKeys] = useState(collapse ? [] : defaultOpenKeys),
    [mode, setMode] = useState("inline"),
    cacheOpenKeys = useRef(openKeys);

  useEffect(() => {
    return props.history.listen(route => {
      setOpenKeys(getDefaultOpenKeys(route, menuConfig));
    });
  }, [props.history, menuConfig]);

  useEffect(() => {
    toggle(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (collapse) {
      cacheOpenKeys.current = openKeys;
      setMode("popup");
      setOpenKeys([]);
    } else {
      setMode("inline");
      setOpenKeys(cacheOpenKeys.current);
    }
    // 关闭React Hook useEffect has missing dependencies检查
    // Icestore导出的变量和函数对hooks dependencies依赖有多次调用问题
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collapse]);

  function onOpenChange (keys) {
    setOpenKeys(keys);
  }

  return (
    <div className={`${styles.iceDesignLayoutAside} ${styles.iceDesignProAside}`}>
      <Logo />
      <Nav
        style={{width: collapse ? "60px" : "200px"}}
        mode={mode}
        iconOnly={collapse}
        hasArrow={!collapse}
        triggerType={collapse ? "hover" : "click"}
        activeDirection={null}
        openKeys={openKeys}
        selectedKeys={[pathname]}
        defaultSelectedKeys={[pathname]}
        onOpen={onOpenChange}
      >
        {
          userProfile.userinfo.roleName === "管理员A" ?
            getNavMenuItems(menuConfig) :
            getNavMenuItems(menuConfig.slice(0, menuConfig.length - 1))
        }
      </Nav>
    </div>
  );
});

export default Aside;
