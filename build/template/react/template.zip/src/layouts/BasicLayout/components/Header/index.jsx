import React, {useEffect, useState} from "react";
import {Balloon, Message, Dialog, Form, Input, Field} from "@alifd/next";
import IceImg from "@icedesign/img";
import FoundationSymbol from "@icedesign/foundation-symbol";
import {withRouter} from "react-router-dom";
import stores from "@/stores";
import {useRequest, request} from "@/utils/request";
import {userLogout} from "@/config/dataSource";

import styles from "./index.module.scss";

const
  FormItem = Form.Item,
  field = new Field({}),
  init = field.init,
  formItemLayout = {
    labelCol: {
      fixedSpan: 4
    }
  };

function Header (props) {
  const {request} = useRequest(userLogout),
    userProfile = stores.useStore("userProfile");

  async function handleLogout () {
    try {
      await request();
      Message.success("已退出");
      props.history.push("/user/login");
    } catch (err) {
      console.error(err);
    }
  }

  const
    {userinfo, fetchData} = userProfile,
    {name, avatar} = userinfo,
    [updatePwdVisible, setUpdatePwdVisible] = useState(false);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <div className={styles.iceDesignLayoutHeader}>
      <div className={styles.headerLeft}/>
      {/* Header 菜单项 begin */}
      <div className={styles.headerRight}>
        <div className={styles.headerAction}>

          {/* Header 右侧内容块 */}
          <Balloon
            trigger={
              <div className={styles.iceDesignHeaderUserpannel}>
                <IceImg
                  height={40}
                  width={40}
                  src={avatar}
                  className={styles.userAvatar}
                />
                <div className={styles.userProfile}>
                  <span className={styles.userName}>
                    {name}
                  </span>
                </div>
                <FoundationSymbol
                  type="angle-down"
                  size="small"
                  className={styles.iconDown}
                />
              </div>
            }
            closable={false}
            className={styles.userProfileMenu}
          >
            <ul>
              <li
                className={styles.userProfileMenuItem}
                onClick={() => { setUpdatePwdVisible(true); }}
              >
                修改密码
              </li>
              <li
                className={styles.userProfileMenuItem}
                onClick={handleLogout}
              >
                退出登录
              </li>
            </ul>
          </Balloon>
        </div>
        {updatePwdVisible ? <UpdatePwd setVisible={setUpdatePwdVisible} handleLogout={handleLogout}/> : null}
      </div>
    </div>
  );
}

export default withRouter(Header);

function UpdatePwd ({
  setVisible,
  handleLogout
}) {
  const
    [formData, setFormData] = useState({});

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  function handleSubmit () {
    field.validate(async (errors, values) => {
      if (errors) {
        Message.error("请检查字段");
        return;
      }

      const {data: success} = await request({
        url: "/user/changePassword",
        method: "PUT",
        data: values
      });

      if (success) {
        Message.success("修改密码成功");
        handleLogout();
      }
    });
  }

  return (
    <Dialog
      title="修改密码"
      visible={true}
      className={styles.container}
      style={{width: 500}}
      closeable="close"
      onCancel={onClose}
      onClose={onClose}
      onOk={() => {
        handleSubmit();
      }}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="原密码" {...formItemLayout} required>
              <Input
                {...init("oldPassword", {
                  rules: [{required: true, message: "必填选项"}]
                })}
                htmlType="password"
              />
            </FormItem>
          </div>
        </div>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="新密码" {...formItemLayout} required>
              <Input
                {...init("newPassword", {
                  rules: [{required: true, message: "必填选项"}]
                })}
                htmlType="password"
              />
            </FormItem>
          </div>
        </div>
      </Form>
    </Dialog>
  );
}