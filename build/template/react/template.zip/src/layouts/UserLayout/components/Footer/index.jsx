import React from "react";
import styles from "./index.module.scss";

export default () => {
  return (
    <div className={styles.footer}>
      <div className={styles.copyright}>
        技术支持微信电话同号：15928158512
        <a
          rel="noopener noreferrer"
          href="http://www.beian.miit.gov.cn/"
          target="_blank">蜀ICP备20019143号</a>
      </div>
    </div>
  );
};