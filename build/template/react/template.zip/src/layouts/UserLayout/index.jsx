import React from "react";
import Layout from "@icedesign/layout";
import Footer from "./components/Footer";
import styles from "./index.module.scss";

export default function UserLayout (props) {
  return (
    <Layout className={styles.userLayout}>
      <div className={styles.layoutLeft}>
        <div className={styles.cover}/>
      </div>
      <div className={styles.layoutRight}>
        <div className={styles.header}>
          <span className={styles.logo}/>
        </div>
        {props.children}
        <Footer />
      </div>
    </Layout>
  );
}
