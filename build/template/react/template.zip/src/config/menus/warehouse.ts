export default {
  name: "仓库",
  path: "/warehouse",
  icon: "https://img.alicdn.com/tfs/TB1VXZEI5_1gK0jSZFqXXcpaXXa-22-22.png",
  children: [
    {
      name: "云仓库",
      path: "/warehouse/inventory"
    },
    {
      name: "入库单",
      path: "/warehouse/stock-in"
    },
    {
      name: "出库单",
      path: "/warehouse/stock-out"
    }
  ]
};