export default {
  name: "首页",
  path: "/home",
  icon: "https://img.alicdn.com/tfs/TB183oHI7T2gK0jSZFkXXcIQFXa-22-22.png"
};