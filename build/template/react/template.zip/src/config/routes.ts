import React from "react";
import userRoutes from "./routes/user";
import BasicLayout from "@/layouts/BasicLayout";
import warehouseRoutes from "./routes/warehouse";

const Dashboard = React.lazy(() => import("@/pages/Dashboard"));
const NotFound = React.lazy(() => import("@/pages/NotFound"));

export interface RouteProps {
  path?: string;
  component?: React.ComponentType<any>;
  redirect?: string;
  children?: Array<RouteProps>;
}

const routerConfig: Array<RouteProps> = [
  ...userRoutes,
  {
    path: "/",
    component: BasicLayout,
    children: [
      {
        path: "/home",
        component: Dashboard
      },
      {
        path: "/exception/404",
        component: NotFound
      },
      {
        path: "/",
        redirect: "/home"
      },
      ...warehouseRoutes,
      {
        component: NotFound
      }
    ]
  }
];

export default routerConfig;
