import React from "react";
import {RouteProps} from "@/config/routes";
const Inventory = React.lazy(() => import("@/pages/warehouse/Inventory"));
const InStockList = React.lazy(() => import("@/pages/warehouse/InStockList"));
const OutStockList = React.lazy(() => import("@/pages/warehouse/OutStockList"));
const PrintInStock = React.lazy(() => import("@/pages/warehouse/Inventory/components/PrintInStock"));
const PrintOutStock = React.lazy(() => import("@/pages/warehouse/Inventory//components/PrintOutStock"));

const warehouseRoutes: Array<RouteProps> = [
  {
    path: "/warehouse/inventory",
    component: Inventory
  },
  {
    path: "/warehouse/stock-in",
    component: InStockList
  },
  {
    path: "/warehouse/stock-in/print",
    component: PrintInStock
  },
  {
    path: "/warehouse/stock-out",
    component: OutStockList
  },
  {
    path: "/warehouse/stock-out/print",
    component: PrintOutStock
  }
];

export default warehouseRoutes;