import React from "react";
import {RouteProps} from "@/config/routes";
import UserLayout from "@/layouts/UserLayout";

const Login = React.lazy(() => import("@/pages/user/Login"));
const NotFound = React.lazy(() => import("@/pages/NotFound"));

const userRoutes: Array<RouteProps> = [
  {
    path: "/user",
    component: UserLayout,
    children: [
      {
        path: "/login",
        component: Login
      },
      {
        path: "/",
        redirect: "/user/login"
      },
      {
        component: NotFound
      }
    ]
  }
];

export default userRoutes;