export const userLogout = {
  url: "/user/logout",
  method: "POST"
};

export const userLogin = {
  url: "/user/login",
  method: "POST"
};
