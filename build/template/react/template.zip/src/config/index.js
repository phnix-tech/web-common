const {
  PUBLIC_PATH
} = require("../env");

/**
 * 前后端共用配置，由于在nodejs中运行所以需要以commonjs模块导出
 * @type {object}
 */
module.exports = {
  publicPath: PUBLIC_PATH
};