// 菜单配置
// asideMenuConfig：侧边导航配置

import home from "./menus/home";
import warehouse from "./menus/warehouse";

const
  asideMenuConfig = [
    home,
    warehouse
  ];

export {asideMenuConfig};
