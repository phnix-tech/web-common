import http from "@/utils/http";
import moment from "moment";

type TabKey = "wine" | "dining" | "other";
type SearchParams = {
  tabKey: TabKey,
  name: string,
  page: number,
  pageSize: number,
};

function dataSourceConverter ({
  dtoList: dataSource = [],
  totalCount: total = 0
}) {
  return {
    dataSource,
    total
  };
}

function paramsConverter ({
  tabKey,
  name,
  page,
  pageSize
}: SearchParams
) {
  return {
    itemType: {
      wine: "酒类",
      dining: "餐饮类",
      other: "其它类"
    }[tabKey],
    searchKey: name,
    start: (page - 1) * pageSize,
    limit: pageSize
  };
}

export default {
  getSuppliers (params: any) {
    return http.get({
      url: "/item/getSuppliers",
      data: params
    });
  },

  getAlliances (params: any) {
    return http.get({
      url: "/item/getAlliances",
      data: params
    });
  },

  getSubTypes () {
    return http.get("/item/getSubTypes");
  },

  inStock (params: any) {
    return http.post({
      url: "/item/in",
      data: params
    });
  },

  outStock (params: any) {
    return http.post({
      url: "/item/out",
      data: params
    });
  },

  getItems ({
    tabKey,
    name,
    subType,
    stock,
    page,
    pageSize
  }: {
    stock: string,
    subType: string | number
  } & SearchParams
  ) {
    const params = {
      subType: (tabKey === "dining" && subType !== -1) ? subType : undefined,
      countLimitType: stock,
      ...paramsConverter({tabKey, name, page, pageSize})
    };

    return http.get({
      url: "/item/getItems",
      data: params
    }).then(dataSourceConverter);
  },

  getInList ({
    tabKey,
    name,
    page,
    pageSize,
    startTime,
    endTime
  }: {
    startTime: moment.Moment | string,
    endTime: moment.Moment | string
  } & SearchParams
  ) {
    startTime = (startTime as moment.Moment).format("YYYY-MM-DD 00:00:00");
    endTime = (endTime as moment.Moment).format("YYYY-MM-DD 23:59:59");

    const params = {
      startTime,
      endTime,
      ...paramsConverter({tabKey, name, page, pageSize})
    };
    return http.get({
      url: "/item/getInList",
      data: params
    }).then(dataSourceConverter);
  },

  getOutList ({
    tabKey,
    name,
    page,
    pageSize,
    startTime,
    endTime
  }: {
    startTime: moment.Moment | string,
    endTime: moment.Moment | string
  } & SearchParams
  ) {
    startTime = (startTime as moment.Moment).format("YYYY-MM-DD 00:00:00");
    endTime = (endTime as moment.Moment).format("YYYY-MM-DD 23:59:59");

    const params = {
      startTime,
      endTime,
      ...paramsConverter({tabKey, name, page, pageSize})
    };
    return http.get({
      url: "/item/getOutList",
      data: params
    }).then(dataSourceConverter);
  },

  updateInPrintCount (id: string) {
    return http.put({
      url: "/item/updateInPrintCount",
      data: {id}
    });
  },

  updateOutPrintCount (id: string) {
    return http.put({
      url: "/item/updateOutPrintCount",
      data: {id}
    });
  },

  getIn (id: string) {
    return http.get({
      url: "/item/getIn",
      data: {id}
    });
  },

  getOut (id: string) {
    return http.get({
      url: "/item/getOut",
      data: {id}
    });
  },

  getItemsFromIds (ids: Array<string>) {
    return http.post({
      url: "/item/getItemsFromIds",
      data: ids
    });
  }
};