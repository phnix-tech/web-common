import http from "@/utils/http";

export default {
  getUserFromCache () {
    return http.get("/user/getUserFromCache");
  }
};