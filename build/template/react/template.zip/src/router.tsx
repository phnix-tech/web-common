import {HashRouter as Router, Switch, Route, Redirect} from "react-router-dom";
import React, {Suspense} from "react";
import path from "path";
import PageLoading from "@/components/PageLoading";
import routes, {RouteProps} from "@/config/routes";

interface RouteItemProps {
  key: string | number;
  path?: string;
  component?: React.ComponentType<any>;
  redirect?: string;
}

function renderRouteItem (props: RouteItemProps) {
  const {
    path: routePath,
    component,
    key,
    redirect
  } = props;

  if (redirect) {
    return (
      <Redirect
        exact
        key={key}
        from={routePath}
        to={redirect}
      />
    );
  }

  return (
    <Route
      exact
      key={key}
      component={component}
      path={routePath}
    />
  );
}

function renderRoute (route: RouteProps, id: number) {
  const {
    component: RouteComponent,
    children,
    ...others
  } = route;

  return (
    <Route
      key={id}
      {...others}
      component={(props: any) => {
        if (children && RouteComponent) {
          return (
            <RouteComponent key={id} {...props}>
              <Suspense fallback={<PageLoading/>}>
                <Switch>
                  {children.map((routeChild: RouteProps, idx: number) => {
                    const {redirect, path: childPath, component} = routeChild;
                    return renderRouteItem({
                      key: `${id}-${idx}`,
                      redirect,
                      path: childPath && path.join(route.path as string, childPath),
                      component
                    });
                  })}
                </Switch>
              </Suspense>
            </RouteComponent>
          );
        }

        return (
          <Suspense fallback={<PageLoading/>}>
            {renderRouteItem({key: id, ...route})}
          </Suspense>
        );
      }}
    />
  );
}

function createRouter () {
  return (
    <Router>
      <Switch>
        {routes.map((route: any, idx: number) => {
          return renderRoute(route, idx);
        })}
      </Switch>
    </Router>
  );
}

export default createRouter;
