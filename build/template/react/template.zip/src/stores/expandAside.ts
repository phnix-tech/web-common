export default {
  collapse: false,

  toggle (bool: boolean | undefined) {
    if (bool === undefined) {
      this.collapse = !this.collapse;
    } else {
      this.collapse = bool;
    }
  }
};
