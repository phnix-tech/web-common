import axios from "axios";
import {Message} from "@alifd/next";

export default {
  userinfo: {
    // 账号
    name: "",
    roleName: "",
    avatar: ""
  },
  userid: "",

  async fetchData () {
    let userInfo;
    try {
      userInfo = (await axios({
        url: "/user/getUserFromCache"
      })).data.data;
    } catch (e) {
      Message.error(e.response.data.message);
      // 未登录
      window.location.href = "#/user/login";
      return;
    }

    const
      {
        username,
        avatar = "https://img.alicdn.com/tfs/TB1L6tBXQyWBuNjy0FpXXassXXa-80-80.png"
      } = userInfo;

    this.userinfo = {...userInfo, name: username, avatar};
    this.userid = username;
  }
};
