const initialState = {};

export default function (
  state = initialState,
  action: {type: string, payload: any}
) {
  switch (action.type) {
    case "action.name":
      return {
        ...state,
        ...action.payload
      };
    default:
      return {...initialState};
  }
}