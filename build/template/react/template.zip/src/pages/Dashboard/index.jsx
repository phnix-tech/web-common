import React from "react";
import {Link} from "react-router-dom";
import IceContainer from "@icedesign/container";
import stores from "@/stores";
import styles from "./index.module.scss";
import moment from "moment";

export default function Dashboard () {
  const
    items = [{
      name: "云仓库",
      link: "/warehouse/inventory",
      img: "https://img.alicdn.com/tfs/TB1zSQBI4v1gK0jSZFFXXb0sXXa-80-80.png"
    }, {
      name: "入库单",
      link: "/warehouse/stock-in",
      img: "https://img.alicdn.com/tfs/TB1KE7yIYr1gK0jSZFDXXb9yVXa-80-80.png"
    }, {
      name: "出库单",
      link: "/warehouse/stock-out",
      img: "https://img.alicdn.com/tfs/TB1vjMwI.z1gK0jSZLeXXb9kVXa-80-80.png"
    }, {
      name: "盘点表",
      link: "/stat/invoicing",
      img: "https://img.alicdn.com/tfs/TB1FS._XGNj0u4jSZFyXXXgMVXa-80-80.png"
    }, {
      name: "销售方",
      link: "/stat/alliance",
      img: "https://img.alicdn.com/tfs/TB1PmuEkIKfxu4jSZPfXXb3dXXa-80-80.png"
    }, {
      name: "品类设置",
      link: "/system/setting/category",
      img: "https://img.alicdn.com/tfs/TB1TQu.XQ9l0K4jSZFKXXXFjpXa-80-80.png"
    }],
    userProfile = stores.useStore("userProfile"),

    now = new moment(),
    hour = now.hour();

  let msg = "早上好";
  if (hour > 9 && hour < 12) {
    msg = "上午好";
  } else if (hour === 12) {
    msg = "中午好";
  } else if (hour > 12 && hour < 18) {
    msg = "下午好";
  } else if (hour >= 18) {
    msg = "晚上好";
  }
  return (
    <IceContainer className={styles.container}>
      <div className={styles.title}>
        <img src="https://img.alicdn.com/tfs/TB1CTcxI1L2gK0jSZPhXXahvXXa-30-30.png" alt=""/>
        {msg},{userProfile.userinfo.name}！
        欢迎使用演示系统！当前时间{now.format("YYYY/MM/DD HH:mm:ss")}
      </div>
      <div className={styles.itemBox}>
        {items.map((item, idx) => {
          return (
            <div className={
              styles.item +
              (idx <= 2 ? " " + styles.mt0 : "") +
              ((idx + 1) % 3 === 0 ? " " + styles.mr0 : "")
            } key={idx}>
              <Link to={item.link}>
                <img src={item.img} alt="img"/>
                {item.name}
              </Link>
            </div>
          );
        })}
      </div>
      <div className={styles.welcome}>技术支持微信电话同号：15928158512</div>
    </IceContainer>
  );
}
