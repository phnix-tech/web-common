import React, {useEffect, useState} from "react";
import moment from "moment";
import {Button, DatePicker, Dialog, Field, Form, Input, Message, Select, Table} from "@alifd/next";
import stores from "@/stores";
import service from "@/services/warehouse";
import styles from "./index.module.scss";
import switchImg from "@/assets/switch.png";

const
  FormItem = Form.Item,
  field = new Field({}),
  init = field.init,
  formItemLayout = {
    labelCol: {
      fixedSpan: 4
    }
  };

function DataTable ({
  dataSource,
  columns,
  estimateText
}) {
  let totalAmount = 0;

  dataSource.forEach(data => {
    if (data.amountOfMoney) {
      totalAmount += Number(data.amountOfMoney);
    }
  });

  if (totalAmount === 0) {
    totalAmount = "--";
  } else {
    totalAmount = totalAmount.toFixed(2);
  }

  return (
    <div className={styles.tableWrapper}>
      <Table
        className={styles.tableBox}
        dataSource={dataSource}
        hasBorder={true}
      >
        {columns.map(item => {
          return (
            <Table.Column
              title={item.title}
              dataIndex={item.dataIndex}
              key={item.key}
              sortable={item.sortable || false}
              cell={item.cell || (value => value)}
              width={item.width || "auto"}
            />
          );
        })}
      </Table>
      <div className={styles.tableFooter}>合计{estimateText ? "（预）" : ""}：{totalAmount}</div>
    </div>
  );
}

export default function (props) {
  const {itemType, record, selectedData} = props;
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!record && selectedData) {
      service
        .getItemsFromIds(selectedData.map(item => item.id))
        .then(items => {
          for (let i = 0; i < selectedData.length; i++) {
            selectedData[i] = items[i];
          }
          setLoading(false);
        });
      return;
    }
    setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return null;
  }

  if (itemType === "dining") {
    return <DiningOutStock {...props}/>;
  } else if (itemType === "other") {
    return <OtherOutStock {...props}/>;
  }

  return <WineOutStock {...props}/>;
}

function WineOutStock ({
  record,
  selectedData,
  setVisible,
  itemType,
  onSubmit
}) {
  let
    initFormData = {},
    isViewMode = false,
    // 无折扣
    noneDiscount = false,
    dftByGroup = false,
    dftByDiscount = false;

  selectedData = record ? record.items : selectedData;
  // deep clone data，阻止数据共享
  selectedData = JSON.parse(JSON.stringify(selectedData));

  if (record) {
    initFormData = record;
    isViewMode = true;
    noneDiscount = true;

    selectedData.forEach(item => {
      dftByGroup = item.displayForCount === false;
      dftByDiscount = item.displayForPrice === false;
      if (
        noneDiscount &&
        Number(item.displayPrice) !== Number(item.realPrice)
      ) {
        noneDiscount = false;
      }
    });
  } else {
    // 新增模式默认值
    selectedData.forEach(item => {
      item.displayForCount = !dftByGroup;
      item.displayForPrice = !dftByDiscount;
      item.batch = "";
      item.note = "";
      item.discount = "";
    });
  }

  const
    userProfile = stores.useStore("userProfile"),
    [dataSource, setDataSource] = useState(selectedData),
    [byGroup, setByGroup] = useState(dftByGroup),
    [byDiscount, setByDiscount] = useState(dftByDiscount),
    [alliances, setAlliances] = useState([]),
    [formData, setFormData] = useState(initFormData),
    [isUseSale, setIsUseSale] = useState(true);

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  function handleSubmit (cbk) {
    field.validate((errors, values) => {
      if (errors) {
        console.log("Errors in form!!!");
        Message.error("请检查数据");
        return;
      }

      for (let i = 0; i < dataSource.length; i++) {
        const item = dataSource[i];
        const {
          count,
          discount
        } = item;
        if (
          [count, discount]
            .filter(el => el !== "")
            .some(el => isNaN(Number(el)))
        ) {
          Message.error("填入非法数据，请检查");
          return;
        }

        // 折扣可以为空，表示无折扣
        if (
          !item.displayForPrice &&
          item.discount !== ""
        ) {
          if (item.discount < 0 || item.discount > 1) {
            Message.error("折扣范围在0到1之间");
            return;
          }

          if (
            (item.discount !== 0 && item.discount !== 1) &&
            !/\.\d{1,2}$/.test(item.discount)
          ) {
            Message.error("折扣最多两位小数");
            return;
          }
        }
      }

      Dialog.confirm({
        content: "该操作确认后不能取消，请谨慎操作",
        onOk: async () => {
          values = {...values};
          values.date = values.date.format("YYYY-MM-DD HH:mm:ss");
          const id = await service.outStock({
            ...values,
            itemType: {
              wine: "酒类",
              dining: "餐饮类",
              other: "其它类"
            }[itemType],
            items: dataSource.map(item => {
              item = {...item};
              delete item.seq;
              return item;
            })
          });

          if (id) {
            Message.success("出库成功");
            setVisible(false);
            if (cbk) {
              cbk({id});
            }
            onSubmit();
          }
        }
      });
    });
  }

  function handleGroupSwitch (batch, record) {
    if (isViewMode) {
      return;
    }

    if (batch === null || batch === undefined) {
      return;
    }

    if (typeof batch === "number" || batch.trim()) {
      record.batch = Number(batch);
      // 按件数
      if (byGroup) {
        record.count = record.group.value * record.batch;
      } else {
        record.count = record.batch;
      }

      if (record.realPrice) {
        record.amountOfMoney = record.count *
          // 假设最大单价一千万
          Math.round(record.realPrice * Math.pow(10, 7)) / Math.pow(10, 7);
        record.amountOfMoney = record.amountOfMoney.toFixed(2);
      }
    } else {
      record.batch = batch;
      record.count = "";
      record.amountOfMoney = "";
    }

    setDataSource([...dataSource]);
  }

  function handleDiscountSwitch (discount, record) {
    if (isViewMode) {
      return;
    }

    if (discount === null || discount === undefined) {
      return;
    }

    record.discount = discount;
    if (discount !== "" && (typeof discount === "number" || discount.trim())) {
      if (byDiscount) {
        record.realPrice = record.displayPrice * discount;
        record.realPrice = record.realPrice.toFixed(2);
      } else {
        record.realPrice = discount;
      }
    } else {
      record.realPrice = record.displayPrice;
    }

    if (record.count) {
      record.amountOfMoney = record.count *
        Math.round(Number(record.realPrice) * Math.pow(10, 7)) / Math.pow(10, 7);
      record.amountOfMoney = record.amountOfMoney.toFixed(2);
    } else {
      record.amountOfMoney = "";
    }

    setDataSource([...dataSource]);
  }

  function handleUseChange (use) {
    setIsUseSale(use === "销售");
  }

  const
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq"
    }, {
      title: "名称",
      dataIndex: "itemName",
      key: "itemName",
      width: 120
    }, {
      title: "规格",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        // 酒类
        // 750ML * 12支
        return `${record.specification.value}${record.specification.unit}` +
          `* ${record.group.value}${record.group.unit}`;
      }
    }, {
      title: (
        <span>
          {byGroup ? "按件数" : "按支数"}
          {isViewMode ? null :
            <button
              onClick={() => {
                setByGroup(!byGroup);
              }}
              style={{verticalAlign: "middle"}}>
              <img
                alt=""
                width="25"
                height="20"
                src={switchImg}/>
            </button>
          }
        </span>
      ),
      htmlTitle: byGroup ? "按件数" : "按支数",
      dataIndex: "batch",
      key: "batch",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.displayForCount ? record.count : record.batch;
        }

        return (
          <Input
            value={record.batch}
            onChange={batch => {
              handleGroupSwitch(batch, record);
            }}/>
        );
      }
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count"
    }, {
      title: "零售价",
      dataIndex: "displayPrice",
      key: "displayPrice"
    }, ...(noneDiscount ? [] : [
      {
        title: (
          <span>
            {byDiscount ? "按折扣" : "按折后价"}
            {isViewMode ? null :
              <button
                onClick={() => {
                  setByDiscount(!byDiscount);
                }}
                style={{verticalAlign: "middle"}}>
                <img
                  alt=""
                  width="25"
                  height="20"
                  src={switchImg}/>
              </button>
            }
          </span>
        ),
        htmlTitle: byDiscount ? "按折扣" : "按折后价",
        dataIndex: "realPrice",
        key: "realPrice",
        cell (val, idx, record) {
          if (isViewMode) {
            return (record.displayForPrice ? record.realPrice : record.discount).toFixed(2);
          }

          return (
            <Input
              value={record.discount}
              onChange={realPrice => {
                handleDiscountSwitch(realPrice, record);
              }}/>
          );
        }
      }
    ]), {
      title: "单价",
      dataIndex: "realPrice",
      key: "realPrice",
      cell (val, idx, record) {
        let realPrice = record.realPrice;
        if (realPrice && realPrice.toFixed) {
          realPrice = realPrice.toFixed(2);
        }
        return realPrice;
      }
    }, {
      title: "小计",
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        let amountOfMoney = record.amountOfMoney;
        if (amountOfMoney && amountOfMoney.toFixed) {
          amountOfMoney = amountOfMoney.toFixed(2);
        }
        return amountOfMoney;
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.note;
        }

        return (
          <Input
            value={record.note}
            onChange={note => {
              record.note = note;
              setDataSource([...dataSource]);
            }}/>
        );
      }
    }];

  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  const date = new moment();

  useEffect(() => {
    ((async () => {
      const alliances = await service.getAlliances({
        enable: true
      });
      setAlliances(alliances);
    })());
  }, []);

  useEffect(() => {
    dataSource.forEach(record => {
      record.displayForCount = !byGroup;
      handleGroupSwitch(record.batch, record);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [byGroup]);

  useEffect(() => {
    dataSource.forEach(record => {
      record.displayForPrice = !byDiscount;
      handleDiscountSwitch(record.discount, record);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [byDiscount]);

  return (
    <Dialog
      title="酒类出库单"
      visible={true}
      className={styles.container}
      style={{width: 1000}}
      closeable="close"
      footer={isViewMode ? (
        <>
          <a
            rel="noopener noreferrer"
            target="_blank"
            href={
              `${window.location.pathname}#/warehouse/stock-out/print?` +
              `id=${record.id}&itemType=${itemType}`
            }>
            <Button
              type="primary"
              onClick={() => {
                return service.updateOutPrintCount(record.id);
              }}>
              打印
            </Button>
          </a>&nbsp;&nbsp;
          <Button onClick={onClose}>
            关闭
          </Button>
        </>
      ) : (
        <>
          <Button
            type="primary"
            onClick={() => {
              handleSubmit();
            }}>
            确认
          </Button>&nbsp;&nbsp;
          <Button
            type="primary"
            onClick={() => {
              handleSubmit(({id}) => {
                service.updateOutPrintCount(id);
                const anchor = document.createElement("a");
                anchor.rel = "noopener noreferrer";
                anchor.target = "_blank";
                anchor.href = `${window.location.pathname}#/warehouse/stock-out/print?` +
                  `id=${id}&itemType=${itemType}`;
                anchor.click();
              });
            }}>
            确认并打印
          </Button>&nbsp;&nbsp;
          <Button onClick={onClose}>
            取消
          </Button>
        </>
      )}
      onClose={onClose}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="时间" {...formItemLayout} required>
              <DatePicker
                style={{width: "100%"}}
                disabled={isViewMode}
                hasClear={false}
                defaultValue={date}
                {...init("date", {
                  initValue: isViewMode ? record.date : date,
                  rules: [{required: true, message: "必填选项"}]
                })}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="说明" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("note", {
                  initValue: isViewMode ? record.note : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="用途" {...formItemLayout}>
              <Select
                style={{width: "100%"}}
                disabled={isViewMode}
                {...init("use", {
                  initValue: isViewMode ? record.use : "销售",
                  props: {
                    onChange: handleUseChange
                  }
                })}>
                <Select.Option value="销售">销售</Select.Option>
                <Select.Option value="前台">前台</Select.Option>
                <Select.Option value="清吧">清吧</Select.Option>
                <Select.Option value="VIP室">VIP室</Select.Option>
                <Select.Option value="赠送">赠送</Select.Option>
                <Select.Option value="其它">其它</Select.Option>
              </Select>
            </FormItem>
          </div>
          <div className={styles.col}>
            {isUseSale ?
              <FormItem
                label="销售方"
                {...formItemLayout}
                required
              >
                <Select
                  style={{width: "100%"}}
                  disabled={isViewMode}
                  hasClear
                  {...init("alliance", {
                    initValue: isViewMode ? record.alliance : undefined,
                    rules: [{required: true, message: "必填选项"}]
                  })}>
                  {alliances.map(alliance => {
                    return (
                      <Select.Option
                        value={alliance.name}
                        key={alliance.name}>
                        {alliance.name}
                      </Select.Option>
                    );
                  })}
                </Select>
              </FormItem>
              : null}
          </div>
        </div>
        <DataTable {...{dataSource, columns}}/>

        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="客户" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("client", {
                  initValue: isViewMode ? record.client : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="复核" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("recheck", {
                  initValue: isViewMode ? record.recheck : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="提货人" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("consignee", {
                  initValue: isViewMode ? record.consignee : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="制单人" {...formItemLayout}>
              <Input
                {...init("creator", {
                  initValue: isViewMode ? record.creator : userProfile.userinfo.displayName
                })}
                disabled
              />
            </FormItem>
          </div>
        </div>
      </Form>
    </Dialog>
  );
}

function DiningOutStock ({
  record,
  selectedData,
  setVisible,
  itemType,
  onSubmit
}) {
  let
    initFormData = {},
    isViewMode = false;

  selectedData = record ? record.items : selectedData;
  selectedData = JSON.parse(JSON.stringify(selectedData));

  if (record) {
    initFormData = record;
    isViewMode = true;
  } else {
    // 新增模式默认值
    selectedData.forEach(item => {
      item.note = "";
      if (
        typeof item.count === "number" &&
        typeof item.realPrice === "number"
      ) {
        item.amountOfMoney = item.count * item.realPrice;
      }
    });
  }

  const
    userProfile = stores.useStore("userProfile"),
    // deep clone data，阻止数据共享
    [dataSource, setDataSource] = useState(selectedData),
    [formData, setFormData] = useState(initFormData);

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  function handleSubmit (cbk) {
    field.validate((errors, values) => {
      if (errors) {
        console.log("Errors in form!!!");
        Message.error("请检查数据");
        return;
      }

      for (let i = 0; i < dataSource.length; i++) {
        const item = dataSource[i];
        const {
          count
        } = item;
        if (
          [count]
            .filter(el => el !== "")
            .some(el => isNaN(Number(el)))
        ) {
          Message.error("填入非法数据，请检查");
          return;
        }
      }

      Dialog.confirm({
        content: "该操作确认后不能取消，请谨慎操作",
        onOk: async () => {
          values = {...values};
          values.date = values.date.format("YYYY-MM-DD HH:mm:ss");
          const id = await service.outStock({
            ...values,
            itemType: {
              wine: "酒类",
              dining: "餐饮类",
              other: "其它类"
            }[itemType],
            items: dataSource.map(item => {
              item = {...item};
              delete item.seq;
              return item;
            })
          });

          if (id) {
            Message.success("出库成功");
            setVisible(false);
            if (cbk) {
              cbk({id});
            }
            onSubmit();
          }
        }
      });
    });
  }

  const
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq"
    }, {
      title: "名称",
      dataIndex: "itemName",
      key: "itemName"
    }, {
      title: "单位",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        return record.unit;
      }
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.count;
        }

        return (
          <Input
            value={record.count}
            onChange={count => {
              if (count.trim()) {
                record.count = count;
                if (record.realPrice) {
                  record.amountOfMoney = (record.count * record.realPrice).toFixed(2);
                }
              } else {
                record.count = "";
              }

              setDataSource([...dataSource]);
            }}/>
        );
      }
    }, {
      title: "单价" + (isViewMode ? "" : "（预）"),
      dataIndex: "realPrice",
      key: "realPrice",
      cell (val, idx, record) {
        return record.realPrice && record.realPrice.toFixed(2);
      }
    }, {
      title: "小计" + (isViewMode ? "" : "（预）"),
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        let amountOfMoney = record.amountOfMoney;
        if (amountOfMoney && amountOfMoney.toFixed) {
          amountOfMoney = amountOfMoney.toFixed(2);
        }
        return amountOfMoney;
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.note;
        }

        return (
          <Input
            value={record.note}
            onChange={note => {
              record.note = note;
              setDataSource([...dataSource]);
            }}/>
        );
      }
    }];

  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  const date = new moment();

  return (
    <Dialog
      title="餐饮类出库单"
      visible={true}
      className={styles.container}
      style={{width: 1000}}
      closeable="close"
      footer={isViewMode ? (
        <>
          <a
            rel="noopener noreferrer"
            target="_blank"
            href={
              `${window.location.pathname}#/warehouse/stock-out/print?` +
              `id=${record.id}&itemType=${itemType}`
            }>
            <Button
              type="primary"
              onClick={() => {
                return service.updateOutPrintCount(record.id);
              }}>
              打印
            </Button>
          </a>&nbsp;&nbsp;
          <Button onClick={onClose}>
            关闭
          </Button>
        </>
      ) : (
        <>
          <Button
            type="primary"
            onClick={() => {
              handleSubmit();
            }}>
            确认
          </Button>&nbsp;&nbsp;
          <Button
            type="primary"
            onClick={() => {
              handleSubmit(({id}) => {
                service.updateOutPrintCount(id);
                const anchor = document.createElement("a");
                anchor.rel = "noopener noreferrer";
                anchor.target = "_blank";
                anchor.href = `${window.location.pathname}#/warehouse/stock-out/print?` +
                  `id=${id}&itemType=${itemType}`;
                anchor.click();
              });
            }}>
            确认并打印
          </Button>&nbsp;&nbsp;
          <Button onClick={onClose}>
            取消
          </Button>
        </>
      )}
      onClose={onClose}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="时间" {...formItemLayout} required>
              <DatePicker
                style={{width: "100%"}}
                hasClear={false}
                disabled={isViewMode}
                defaultValue={date}
                {...init("date", {
                  initValue: isViewMode ? record.date : date,
                  rules: [{required: true, message: "必填选项"}]
                })}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="说明" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("note", {
                  initValue: isViewMode ? record.note : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="领用部门" {...formItemLayout}>
              <Select
                style={{width: "100%"}}
                disabled={isViewMode}
                {...init("use", {
                  initValue: isViewMode ? record.use : "厨房"
                })}>
                <Select.Option value="厨房">厨房</Select.Option>
                <Select.Option value="前台">前台</Select.Option>
                <Select.Option value="清吧">清吧</Select.Option>
                <Select.Option value="其它">其它</Select.Option>
              </Select>
            </FormItem>
          </div>
        </div>
        <DataTable {...{dataSource, columns, estimateText: !isViewMode}}/>

        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="领用人" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("consignee", {
                  initValue: isViewMode ? record.consignee : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="制单人" {...formItemLayout}>
              <Input
                {...init("creator", {
                  initValue: isViewMode ? record.creator : userProfile.userinfo.displayName
                })}
                disabled
              />
            </FormItem>
          </div>
          <div className={styles.col}/>
        </div>
      </Form>
    </Dialog>
  );
}

function OtherOutStock ({
  record,
  selectedData,
  setVisible,
  itemType,
  onSubmit
}) {
  let
    initFormData = {},
    isViewMode = false;

  selectedData = record ? record.items : selectedData;
  // deep clone data，阻止数据共享
  selectedData = JSON.parse(JSON.stringify(selectedData));

  if (record) {
    initFormData = record;
    isViewMode = true;
  } else {
    // 新增模式默认值
    selectedData.forEach(item => {
      item.note = "";
      if (
        typeof item.count === "number" &&
        typeof item.realPrice === "number"
      ) {
        item.amountOfMoney = item.count * item.realPrice;
      }
    });
  }

  const
    userProfile = stores.useStore("userProfile"),
    [dataSource, setDataSource] = useState(selectedData),
    [formData, setFormData] = useState(initFormData);

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  function handleSubmit (cbk) {
    field.validate((errors, values) => {
      if (errors) {
        console.log("Errors in form!!!");
        Message.error("请检查数据");
        return;
      }

      for (let i = 0; i < dataSource.length; i++) {
        const item = dataSource[i];
        const {
          count
        } = item;
        if (
          [count]
            .filter(el => el !== "")
            .some(el => isNaN(Number(el)))
        ) {
          Message.error("填入非法数据，请检查");
          return;
        }
      }

      Dialog.confirm({
        content: "该操作确认后不能取消，请谨慎操作",
        onOk: async () => {
          values = {...values};
          values.date = values.date.format("YYYY-MM-DD HH:mm:ss");
          const id = await service.outStock({
            ...values,
            itemType: {
              wine: "酒类",
              dining: "餐饮类",
              other: "其它类"
            }[itemType],
            items: dataSource.map(item => {
              item = {...item};
              delete item.seq;
              return item;
            })
          });

          if (id) {
            Message.success("出库成功");
            setVisible(false);
            if (cbk) {
              cbk({id});
            }
            onSubmit();
          }
        }
      });
    });
  }

  const
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq"
    }, {
      title: "名称",
      dataIndex: "itemName",
      key: "itemName"
    }, {
      title: "单位",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        return record.unit;
      }
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.count;
        }

        return (
          <Input
            value={record.count}
            onChange={count => {
              if (count.trim()) {
                record.count = count;
                if (record.realPrice) {
                  record.amountOfMoney = (record.count * record.realPrice).toFixed(2);
                }
              } else {
                record.count = "";
              }

              setDataSource([...dataSource]);
            }}/>
        );
      }
    }, {
      title: "单价" + (isViewMode ? "" : "（预）"),
      dataIndex: "realPrice",
      key: "realPrice",
      cell (val, idx, record) {
        return record.realPrice && record.realPrice.toFixed(2);
      }
    }, {
      title: "小计" + (isViewMode ? "" : "（预）"),
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        let amountOfMoney = record.amountOfMoney;
        if (amountOfMoney && amountOfMoney.toFixed) {
          amountOfMoney = amountOfMoney.toFixed(2);
        }
        return amountOfMoney;
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.note;
        }

        return (
          <Input
            value={record.note}
            onChange={note => {
              record.note = note;
              setDataSource([...dataSource]);
            }}/>
        );
      }
    }];

  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  const date = new moment();

  return (
    <Dialog
      title="其它类出库单"
      visible={true}
      className={styles.container}
      style={{width: 1000}}
      closeable="close"
      footer={isViewMode ? (
        <>
          <a
            rel="noopener noreferrer"
            target="_blank"
            href={
              `${window.location.pathname}#/warehouse/stock-out/print?` +
              `id=${record.id}&itemType=${itemType}`
            }>
            <Button
              type="primary"
              onClick={() => {
                return service.updateOutPrintCount(record.id);
              }}>
              打印
            </Button>
          </a>&nbsp;&nbsp;
          <Button onClick={onClose}>
            关闭
          </Button>
        </>
      ) : (
        <>
          <Button
            type="primary"
            onClick={() => {
              handleSubmit();
            }}>
            确认
          </Button>&nbsp;&nbsp;
          <Button
            type="primary"
            onClick={() => {
              handleSubmit(({id}) => {
                service.updateOutPrintCount(id);
                const anchor = document.createElement("a");
                anchor.rel = "noopener noreferrer";
                anchor.target = "_blank";
                anchor.href = `${window.location.pathname}#/warehouse/stock-out/print?` +
                  `id=${id}&itemType=${itemType}`;
                anchor.click();
              });
            }}>
            确认并打印
          </Button>&nbsp;&nbsp;
          <Button onClick={onClose}>
            取消
          </Button>
        </>
      )}
      onClose={onClose}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="时间" {...formItemLayout} required>
              <DatePicker
                style={{width: "100%"}}
                hasClear={false}
                disabled={isViewMode}
                defaultValue={date}
                {...init("date", {
                  initValue: isViewMode ? record.date : date,
                  rules: [{required: true, message: "必填选项"}]
                })}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="说明" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("note", {
                  initValue: isViewMode ? record.note : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="领用部门" {...formItemLayout}>
              <Select
                style={{width: "100%"}}
                disabled={isViewMode}
                {...init("use", {
                  initValue: isViewMode ? record.use : "办公室"
                })}>
                <Select.Option value="办公室">办公室</Select.Option>
                <Select.Option value="其它">其它</Select.Option>
              </Select>
            </FormItem>
          </div>
        </div>
        <DataTable {...{dataSource, columns, estimateText: !isViewMode}}/>

        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="领用人" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("consignee", {
                  initValue: isViewMode ? record.consignee : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="制单人" {...formItemLayout}>
              <Input
                {...init("creator", {
                  initValue: isViewMode ? record.creator : userProfile.userinfo.displayName
                })}
                disabled
              />
            </FormItem>
          </div>
          <div className={styles.col}/>
        </div>
      </Form>
    </Dialog>
  );
}