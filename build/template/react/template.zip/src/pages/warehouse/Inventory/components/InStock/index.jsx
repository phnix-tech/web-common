import {
  DatePicker, Dialog, Field, Form,
  Input, Table, Message, Button, Select
} from "@alifd/next";
import React, {useEffect, useState} from "react";
import moment from "moment";
import stores from "@/stores";
import service from "@/services/warehouse";
import styles from "./index.module.scss";
import switchImg from "@/assets/switch.png";

const
  FormItem = Form.Item,
  field = new Field({}),
  init = field.init,
  formItemLayout = {
    labelCol: {
      fixedSpan: 4
    }
  };

function DataTable ({
  dataSource,
  columns
}) {
  let totalAmount = 0;

  dataSource.forEach(data => {
    if (data.amountOfMoney && data.amountOfMoney !== "") {
      totalAmount += Number(data.amountOfMoney);
    }
  });

  if (totalAmount === 0) {
    totalAmount = "--";
  } else {
    totalAmount = totalAmount.toFixed(2);
  }

  return (
    <div>
      <Table
        className={styles.tableBox}
        dataSource={dataSource}
        hasBorder={true}
      >
        {columns.map(item => {
          return (
            <Table.Column
              title={item.title}
              dataIndex={item.dataIndex}
              key={item.key}
              sortable={item.sortable || false}
              cell={item.cell || (value => value)}
              width={item.width || "auto"}
            />
          );
        })}
      </Table>
      <div className={styles.tableFooter}>合计：{totalAmount}</div>
    </div>
  );
}

async function getSuppliers ({
  setSuppliers
}) {
  const suppliers = await service.getSuppliers({
    enable: true
  });
  setSuppliers(suppliers);
}

export default function (props) {
  const {itemType} = props;
  if (itemType === "dining") {
    return <DiningInStock {...props}/>;
  } else if (itemType === "other") {
    return <OtherInStock {...props}/>;
  }

  return <WineInStock {...props}/>;
}

function handleSubmit ({
  itemType,
  dataSource,
  setVisible,
  onSubmit
}) {
  field.validate((errors, values) => {
    if (errors) {
      console.log("Errors in form!!!");
      Message.error("请检查数据");
      return;
    }

    if (itemType === "wine") {
      for (let i = 0; i < dataSource.length; i++) {
        const item = dataSource[i];
        const {
          count,
          discount
        } = item;
        if (
          [count, discount]
            .filter(el => el !== "")
            .some(el => isNaN(Number(el)))
        ) {
          Message.error("填入非法数据，请检查");
          return;
        }

        // 折扣可以为空，表示无折扣
        if (
          !item.displayForPrice &&
          item.discount !== ""
        ) {
          if (item.discount < 0 || item.discount > 1) {
            Message.error("折扣范围在0到1之间");
            return;
          }

          if (
            (item.discount !== 0 && item.discount !== 1) &&
            !/\.\d{1,2}$/.test(item.discount)
          ) {
            Message.error("折扣最多两位小数");
            return;
          }
        }
      }
    } else {
      for (let i = 0; i < dataSource.length; i++) {
        const item = dataSource[i];
        const {
          count,
          amountOfMoney
        } = item;
        if (
          [count, amountOfMoney]
            .filter(el => el !== "")
            .some(el => isNaN(Number(el)))
        ) {
          Message.error("填入非法数据，请检查");
          return;
        }
      }
    }

    Dialog.confirm({
      content: "该操作确认后不能取消，请谨慎操作",
      onOk: async () => {
        values = {...values};
        values.date = values.date.format("YYYY-MM-DD HH:mm:ss");
        const id = await service.inStock({
          ...values,
          itemType: {
            wine: "酒类",
            dining: "餐饮类",
            other: "其它类"
          }[itemType],
          items: dataSource.map(item => {
            item = {...item};
            delete item.seq;
            return item;
          })
        });

        if (id) {
          Message.success("入库成功");
          setVisible(false);
          onSubmit({id});
        }
      }
    });
  });
}

function WineInStock ({
  record,
  selectedData,
  setVisible,
  itemType,
  onSubmit
}) {
  let
    initFormData = {},
    isViewMode = false,
    // 无折扣
    noneDiscount = false,
    dftByGroup = false,
    dftByDiscount = false;

  selectedData = record ? record.items : selectedData;
  selectedData = JSON.parse(JSON.stringify(selectedData));

  // 查看详情
  if (record) {
    initFormData = record;
    isViewMode = true;
    noneDiscount = true;

    selectedData.forEach(item => {
      dftByGroup = item.displayForCount === false;
      dftByDiscount = item.displayForPrice === false;
      if (
        noneDiscount &&
        Number(item.displayPrice) !== Number(item.realPrice)
      ) {
        noneDiscount = false;
      }
    });
  } else {
    // 新增模式默认值
    selectedData.forEach(item => {
      item.displayForCount = !dftByGroup;
      item.displayForPrice = !dftByDiscount;
      // 重置默认按件数值为空
      item.batch = "";
      item.count = "";
      item.note = "";
      item.discount = "";
    });
  }

  const
    userProfile = stores.useStore("userProfile"),
    // deep clone data，阻止数据共享
    [dataSource, setDataSource] = useState(selectedData),
    // 按件数
    [byGroup, setByGroup] = useState(dftByGroup),
    // 按折扣
    [byDiscount, setByDiscount] = useState(dftByDiscount),
    [formData, setFormData] = useState(initFormData);

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  function handleGroupSwitch (batch, record) {
    if (isViewMode) {
      return;
    }

    if (batch === null || batch === undefined) {
      return;
    }

    if (typeof batch === "number" || batch.trim()) {
      record.batch = Number(batch);
      // 按件数
      if (byGroup) {
        record.count = record.group.value * record.batch;
      } else {
        record.count = record.batch;
      }

      if (record.realPrice) {
        record.amountOfMoney = record.count *
          // 假设最大单价一千万
          Math.round(record.realPrice * Math.pow(10, 7)) / Math.pow(10, 7);

        record.amountOfMoney = record.amountOfMoney.toFixed(2);
      }
    } else {
      record.batch = batch;
      record.count = "";
      record.amountOfMoney = "";
    }

    setDataSource([...dataSource]);
  }

  function handleDiscountSwitch (discount, record) {
    if (isViewMode) {
      return;
    }

    if (discount === null || discount === undefined) {
      return;
    }

    record.discount = discount;
    if (discount !== "" && (typeof discount === "number" || discount.trim())) {
      if (byDiscount) {
        record.realPrice = record.displayPrice * discount;
        record.realPrice = record.realPrice.toFixed(2);
      } else {
        record.realPrice = discount;
      }
    } else {
      record.realPrice = record.displayPrice;
    }

    if (record.count) {
      record.amountOfMoney = record.count *
        Math.round(Number(record.realPrice) * Math.pow(10, 7)) / Math.pow(10, 7);

      record.amountOfMoney = record.amountOfMoney.toFixed(2);
    } else {
      record.amountOfMoney = "";
    }

    setDataSource([...dataSource]);
  }

  useEffect(() => {
    dataSource.forEach(record => {
      record.displayForCount = !byGroup;
      handleGroupSwitch(record.batch, record);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [byGroup]);

  useEffect(() => {
    dataSource.forEach(record => {
      record.displayForPrice = !byDiscount;
      handleDiscountSwitch(record.discount, record);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [byDiscount]);

  const
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq"
    }, {
      title: "名称",
      dataIndex: "itemName",
      key: "itemName",
      width: 120
    }, {
      title: "规格",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        // 酒类
        // 750ML * 12支
        return `${record.specification.value}${record.specification.unit}` +
          `* ${record.group.value}${record.group.unit}`;
      }
    }, {
      title: (
        <span>
          {byGroup ? "按件数" : "按支数"}
          {isViewMode ? null :
            <button
              onClick={() => {
                setByGroup(!byGroup);
              }}
              style={{verticalAlign: "middle"}}>
              <img
                alt=""
                width="25"
                height="20"
                src={switchImg}/>
            </button>
          }
        </span>
      ),
      htmlTitle: byGroup ? "按件数" : "按支数",
      dataIndex: "batch",
      key: "batch",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.displayForCount ? record.count : record.batch;
        }

        return (
          <Input
            value={record.batch}
            onChange={batch => {
              handleGroupSwitch(batch, record);
            }}/>
        );
      }
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count"
    }, {
      title: "零售价",
      dataIndex: "displayPrice",
      key: "displayPrice"
    }, ...(noneDiscount ? [] : [
      {
        title: (
          <span>
            {byDiscount ? "按折扣" : "按折后价"}
            {isViewMode ? null :
              <button
                onClick={() => {
                  setByDiscount(!byDiscount);
                }}
                style={{verticalAlign: "middle"}}>
                <img
                  alt=""
                  width="25"
                  height="20"
                  src={switchImg}/>
              </button>
            }
          </span>
        ),
        htmlTitle: byDiscount ? "按折扣" : "按折后价",
        dataIndex: "realPrice",
        key: "realPrice",
        cell (val, idx, record) {
          if (isViewMode) {
            return (record.displayForPrice ? record.realPrice : record.discount).toFixed(2);
          }

          return (
            <Input
              value={record.discount}
              onChange={realPrice => {
                handleDiscountSwitch(realPrice, record);
              }}/>
          );
        }
      }
    ]), {
      title: "单价",
      dataIndex: "realPrice",
      key: "realPrice",
      cell (val, idx, record) {
        let realPrice = record.realPrice;
        if (realPrice && realPrice.toFixed) {
          realPrice = realPrice.toFixed(2);
        }
        return realPrice;
      }
    }, {
      title: "小计",
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        let amountOfMoney = record.amountOfMoney;
        if (amountOfMoney && amountOfMoney.toFixed) {
          amountOfMoney = amountOfMoney.toFixed(2);
        }
        return amountOfMoney;
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note",
      cell (val, idx, record) {
        if (isViewMode) {
          return record.note;
        }

        return (
          <Input
            value={record.note}
            onChange={note => {
              record.note = note;
              setDataSource([...dataSource]);
            }}/>
        );
      }
    }];

  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  const date = new moment();

  return (
    <Dialog
      title={{
        wine: "酒类入库单",
        dining: "餐饮类入库单",
        other: "其它类入库单"
      }[itemType]}
      visible={true}
      className={styles.container}
      style={{width: 1000}}
      closeable="close"
      footer={isViewMode ? (
        <>
          <a
            rel="noopener noreferrer"
            target="_blank"
            href={
              `${window.location.pathname}#/warehouse/stock-in/print?` +
              `id=${record.id}&itemType=${itemType}`
            }>
            <Button
              type="primary"
              onClick={() => {
                return service.updateInPrintCount(record.id);
              }}>
              打印
            </Button>
          </a>&nbsp;&nbsp;
          <Button onClick={onClose}>
            关闭
          </Button>
        </>
      ) : (
        <>
          <Button
            type="primary"
            onClick={() => {
              handleSubmit({
                itemType,
                dataSource,
                setVisible,
                onSubmit
              });
            }}>
            确认
          </Button>&nbsp;&nbsp;
          <Button
            type="primary"
            onClick={() => {
              handleSubmit({
                itemType,
                dataSource,
                setVisible,
                onSubmit ({id}) {
                  service.updateInPrintCount(id);
                  const anchor = document.createElement("a");
                  anchor.rel = "noopener noreferrer";
                  anchor.target = "_blank";
                  anchor.href = `${window.location.pathname}#/warehouse/stock-in/print?` +
                    `id=${id}&itemType=${itemType}`;
                  anchor.click();

                  onSubmit();
                }
              });
            }}>
            确认并打印
          </Button>&nbsp;&nbsp;
          <Button onClick={onClose}>
            取消
          </Button>
        </>
      )}
      onClose={onClose}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="时间" {...formItemLayout} required>
              <DatePicker
                hasClear={false}
                defaultValue={date}
                disabled={isViewMode}
                {...init("date", {
                  initValue: isViewMode ? record.date : date,
                  rules: [{required: true, message: "必填选项"}]
                })}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="说明" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("note", {
                  initValue: isViewMode ? record.note : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}/>
        </div>
        <DataTable {...{dataSource, columns}}/>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="收货人" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("consignee", {
                  initValue: isViewMode ? record.consignee : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="制单人" {...formItemLayout}>
              <Input
                {...init("creator", {
                  initValue: isViewMode ? record.creator : userProfile.userinfo.displayName
                })}
                disabled
              />
            </FormItem>
          </div>
          <div className={styles.col}/>
        </div>
      </Form>
    </Dialog>
  );
}

function DiningInStock ({
  record,
  selectedData,
  setVisible,
  itemType,
  onSubmit
}) {
  let
    initFormData = {},
    isViewMode = false;

  selectedData = record ? record.items : selectedData;
  // deep clone data，阻止数据共享
  selectedData = JSON.parse(JSON.stringify(selectedData));

  if (record) {
    initFormData = record;
    isViewMode = true;
  } else {
    // 新增模式默认值
    selectedData.forEach(item => {
      item.count = "";
      item.note = "";
      item.amountOfMoney = "";
    });
  }

  const
    userProfile = stores.useStore("userProfile"),
    [dataSource, setDataSource] = useState(selectedData),
    [formData, setFormData] = useState(initFormData),
    [suppliers, setSuppliers] = useState([]);

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  const
    columns = [
      {
        title: "序号",
        dataIndex: "seq",
        key: "seq"
      },
      {
        title: "名称",
        dataIndex: "itemName",
        key: "itemName"
      },
      {
        title: "单位",
        dataIndex: "specification",
        key: "specification",
        cell (val, idx, record) {
          return record.unit;
        }
      },
      {
        title: "数量",
        dataIndex: "count",
        key: "count",
        cell (val, idx, record) {
          if (isViewMode) {
            return record.count;
          }

          return (
            <Input
              value={record.count}
              onChange={count => {
                if (count.trim()) {
                  record.count = count;
                  if (record.amountOfMoney) {
                    record.realPrice = (record.amountOfMoney / Number(record.count)).toFixed(2);
                  }
                } else {
                  record.count = "";
                  record.realPrice = "";
                }

                setDataSource([...dataSource]);
              }}/>
          );
        }
      },
      {
        title: "零售价",
        dataIndex: "realPrice",
        key: "realPrice",
        cell (val, idx, record) {
          let realPrice = record.realPrice;
          if (realPrice && realPrice.toFixed) {
            realPrice = realPrice.toFixed(2);
          }
          return realPrice;
        }
      },
      {
        title: "小计",
        dataIndex: "amountOfMoney",
        key: "amountOfMoney",
        cell (val, idx, record) {
          if (isViewMode) {
            let amountOfMoney = record.amountOfMoney;
            if (amountOfMoney && amountOfMoney.toFixed) {
              amountOfMoney = amountOfMoney.toFixed(2);
            }
            return amountOfMoney;
          }

          return (
            <Input
              value={record.amountOfMoney}
              onChange={amountOfMoney => {
                if (amountOfMoney.trim()) {
                  record.amountOfMoney = amountOfMoney;
                  if (record.count) {
                    record.realPrice = (record.amountOfMoney / Number(record.count)).toFixed(2);
                  }
                } else {
                  record.amountOfMoney = "";
                  record.realPrice = "";
                }

                setDataSource([...dataSource]);
              }}/>
          );
        }
      },
      {
        title: "备注",
        dataIndex: "note",
        key: "note",
        cell (val, idx, record) {
          if (isViewMode) {
            return record.note;
          }

          return (
            <Input
              value={record.note}
              onChange={note => {
                record.note = note;
                setDataSource([...dataSource]);
              }}/>
          );
        }
      }
    ];

  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  const date = new moment();

  useEffect(() => {
    getSuppliers({
      setSuppliers
    }).then();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Dialog
      title={{
        wine: "酒类入库单",
        dining: "餐饮类入库单",
        other: "其它类入库单"
      }[itemType]}
      visible={true}
      className={styles.container}
      style={{width: 1000}}
      closeable="close"
      footer={isViewMode ? (
        <>
          <a
            rel="noopener noreferrer"
            target="_blank"
            href={
              `${window.location.pathname}#/warehouse/stock-in/print?` +
              `id=${record.id}&itemType=${itemType}`
            }>
            <Button
              type="primary"
              onClick={() => {
                return service.updateInPrintCount(record.id);
              }}>
              打印
            </Button>
          </a>&nbsp;&nbsp;
          <Button onClick={onClose}>
            关闭
          </Button>
        </>
      ) : (
        <>
          <Button
            type="primary"
            onClick={() => {
              handleSubmit({
                itemType,
                dataSource,
                setVisible,
                onSubmit
              });
            }}>
            确认
          </Button>&nbsp;&nbsp;
          <Button
            type="primary"
            onClick={() => {
              handleSubmit({
                itemType,
                dataSource,
                setVisible,
                onSubmit ({id}) {
                  service.updateInPrintCount(id);
                  const anchor = document.createElement("a");
                  anchor.rel = "noopener noreferrer";
                  anchor.target = "_blank";
                  anchor.href = `${window.location.pathname}#/warehouse/stock-in/print?` +
                    `id=${id}&itemType=${itemType}`;
                  anchor.click();

                  onSubmit();
                }
              });
            }}>
            确认并打印
          </Button>&nbsp;&nbsp;
          <Button onClick={onClose}>
            取消
          </Button>
        </>
      )}
      onCancel={onClose}
      onClose={onClose}
      onOk={() => {
        handleSubmit({
          itemType,
          dataSource,
          setVisible,
          onSubmit
        });
      }}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="时间" {...formItemLayout} required>
              <DatePicker
                hasClear={false}
                defaultValue={date}
                disabled={isViewMode}
                {...init("date", {
                  initValue: isViewMode ? record.date : date,
                  rules: [{required: true, message: "必填选项"}]
                })}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="说明" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("note", {
                  initValue: isViewMode ? record.note : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem
              label="供应商"
              {...formItemLayout}
              required
            >
              <Select
                disabled={isViewMode}
                {...init("supplier", {
                  rules: [{required: true, message: "必填选项"}],
                  initValue: isViewMode ? record.supplier : undefined
                })}>
                {suppliers.map(supplier => {
                  return (
                    <Select.Option
                      value={supplier.name}
                      key={supplier.name}>
                      {supplier.name}
                    </Select.Option>
                  );
                })}
              </Select>
            </FormItem>
          </div>
        </div>
        <DataTable {...{dataSource, columns}}/>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="采购" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("purchasingMan", {
                  initValue: isViewMode ? record.purchasingMan : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="收货人" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("consignee", {
                  initValue: isViewMode ? record.consignee : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="制单人" {...formItemLayout}>
              <Input
                {...init("creator", {
                  initValue: isViewMode ? record.creator : userProfile.userinfo.displayName
                })}
                disabled
              />
            </FormItem>
          </div>
        </div>
      </Form>
    </Dialog>
  );
}

function OtherInStock ({
  record,
  selectedData,
  setVisible,
  itemType,
  onSubmit
}) {
  let
    initFormData = {},
    isViewMode = false;

  selectedData = record ? record.items : selectedData;
  // deep clone data，阻止数据共享
  selectedData = JSON.parse(JSON.stringify(selectedData));

  if (record) {
    initFormData = record;
    isViewMode = true;
  } else {
    // 新增模式默认值
    selectedData.forEach(item => {
      item.count = "";
      item.note = "";
      item.amountOfMoney = "";
    });
  }

  const
    userProfile = stores.useStore("userProfile"),
    [dataSource, setDataSource] = useState(selectedData),
    [formData, setFormData] = useState(initFormData),
    [suppliers, setSuppliers] = useState([]);

  function onClose () {
    setVisible(false);
  }

  function onChange (value) {
    setFormData(value);
  }

  const
    columns = [
      {
        title: "序号",
        dataIndex: "seq",
        key: "seq"
      },
      {
        title: "名称",
        dataIndex: "itemName",
        key: "itemName"
      },
      {
        title: "单位",
        dataIndex: "specification",
        key: "specification",
        cell (val, idx, record) {
          return record.unit;
        }
      },
      {
        title: "数量",
        dataIndex: "count",
        key: "count",
        cell (val, idx, record) {
          if (isViewMode) {
            return record.count;
          }

          return (
            <Input
              value={record.count}
              onChange={count => {
                if (count.trim()) {
                  record.count = count;
                  if (record.amountOfMoney) {
                    record.realPrice = (record.amountOfMoney / Number(record.count)).toFixed(2);
                  }
                } else {
                  record.count = "";
                  record.realPrice = "";
                }

                setDataSource([...dataSource]);
              }}/>
          );
        }
      },
      {
        title: "零售价",
        dataIndex: "realPrice",
        key: "realPrice",
        cell (val, idx, record) {
          let realPrice = record.realPrice;
          if (realPrice && realPrice.toFixed) {
            realPrice = realPrice.toFixed(2);
          }
          return realPrice;
        }
      },
      {
        title: "小计",
        dataIndex: "amountOfMoney",
        key: "amountOfMoney",
        cell (val, idx, record) {
          if (isViewMode) {
            let amountOfMoney = record.amountOfMoney;
            if (amountOfMoney && amountOfMoney.toFixed) {
              amountOfMoney = amountOfMoney.toFixed(2);
            }
            return amountOfMoney;
          }

          return (
            <Input
              value={record.amountOfMoney}
              onChange={amountOfMoney => {
                if (amountOfMoney.trim()) {
                  record.amountOfMoney = amountOfMoney;
                  if (record.count) {
                    record.realPrice = (record.amountOfMoney / Number(record.count)).toFixed(2);
                  }
                } else {
                  record.amountOfMoney = "";
                  record.realPrice = "";
                }
                setDataSource([...dataSource]);
              }}/>
          );
        }
      },
      {
        title: "备注",
        dataIndex: "note",
        key: "note",
        cell (val, idx, record) {
          if (isViewMode) {
            return record.note;
          }

          return (
            <Input
              value={record.note}
              onChange={note => {
                record.note = note;
                setDataSource([...dataSource]);
              }}/>
          );
        }
      }
    ];

  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  const date = new moment();

  useEffect(() => {
    getSuppliers({
      setSuppliers
    }).then();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Dialog
      title={{
        wine: "酒类入库单",
        dining: "餐饮类入库单",
        other: "其它类入库单"
      }[itemType]}
      visible={true}
      className={styles.container}
      style={{width: 1000}}
      closeable="close"
      footer={isViewMode ? (
        <>
          <a
            rel="noopener noreferrer"
            target="_blank"
            href={
              `${window.location.pathname}#/warehouse/stock-in/print?` +
              `id=${record.id}&itemType=${itemType}`
            }>
            <Button
              type="primary"
              onClick={() => {
                return service.updateInPrintCount(record.id);
              }}>
              打印
            </Button>
          </a>&nbsp;&nbsp;
          <Button onClick={onClose}>
            关闭
          </Button>
        </>
      ) : (
        <>
          <Button
            type="primary"
            onClick={() => {
              handleSubmit({
                itemType,
                dataSource,
                setVisible,
                onSubmit
              });
            }}>
            确认
          </Button>&nbsp;&nbsp;
          <Button
            type="primary"
            onClick={() => {
              handleSubmit({
                itemType,
                dataSource,
                setVisible,
                onSubmit ({id}) {
                  service.updateInPrintCount(id);
                  const anchor = document.createElement("a");
                  anchor.rel = "noopener noreferrer";
                  anchor.target = "_blank";
                  anchor.href = `${window.location.pathname}#/warehouse/stock-in/print?` +
                    `id=${id}&itemType=${itemType}`;
                  anchor.click();

                  onSubmit();
                }
              });
            }}>
            确认并打印
          </Button>&nbsp;&nbsp;
          <Button onClick={onClose}>
            取消
          </Button>
        </>
      )}
      onCancel={onClose}
      onClose={onClose}
      onOk={() => {
        handleSubmit({
          itemType,
          dataSource,
          setVisible,
          onSubmit
        });
      }}
    >
      <Form field={field} onChange={onChange} value={formData}>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="时间" {...formItemLayout} required>
              <DatePicker
                hasClear={false}
                defaultValue={date}
                disabled={isViewMode}
                {...init("date", {
                  initValue: isViewMode ? record.date : date,
                  rules: [{required: true, message: "必填选项"}]
                })}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="说明" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("note", {
                  initValue: isViewMode ? record.note : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem
              label="供应商"
              {...formItemLayout}
              required
            >
              <Select
                disabled={isViewMode}
                {...init("supplier", {
                  rules: [{required: true, message: "必填选项"}],
                  initValue: isViewMode ? record.supplier : undefined
                })}>
                {suppliers.map(supplier => {
                  return (
                    <Select.Option
                      value={supplier.name}
                      key={supplier.name}>
                      {supplier.name}
                    </Select.Option>
                  );
                })}
              </Select>
            </FormItem>
          </div>
        </div>
        <DataTable {...{dataSource, columns}}/>
        <div className={styles.row}>
          <div className={styles.col}>
            <FormItem label="采购" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("purchasingMan", {
                  initValue: isViewMode ? record.purchasingMan : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="收货人" {...formItemLayout}>
              <Input
                disabled={isViewMode}
                {...init("consignee", {
                  initValue: isViewMode ? record.consignee : undefined,
                  rules: [{required: false}]
                })}
                placeholder={isViewMode ? undefined : "非必填"}
              />
            </FormItem>
          </div>
          <div className={styles.col}>
            <FormItem label="制单人" {...formItemLayout}>
              <Input
                {...init("creator", {
                  initValue: isViewMode ? record.creator : userProfile.userinfo.displayName
                })}
                disabled
              />
            </FormItem>
          </div>
        </div>
      </Form>
    </Dialog>
  );
}