import React, {useEffect, useState} from "react";
import {Input, Select, Button} from "@alifd/next";
import {connect} from "react-redux";
import {context, mapStateToProps, mapDispatchToProps} from "../../store";
import service from "@/services/warehouse";
import styles from "./index.module.scss";

function SearchCondition (props) {
  const
    {tabKey, name, subType, stock} = props.searchParams,
    defaultSubTypes = [
      {
        id: -1,
        name: "不限"
      }
    ],
    [subTypes, setSubTypes] = useState([...defaultSubTypes]);

  useEffect(() => {
    ((async () => {
      if (tabKey === "dining") {
        const subTypes = await service.getSubTypes();
        setSubTypes([...defaultSubTypes, ...subTypes]);
      }
    })());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tabKey]);

  return (
    <div className={styles.searchBox}>
      关键字&nbsp;&nbsp;
      <Input
        value={name}
        placeholder="输入商品名称"
        onChange={name => {
          props.setSearchParams({name});
          props.resetPageSearch();
        }}/>
      {
        tabKey === "dining" ?
          <>
            &nbsp;&nbsp;类型&nbsp;&nbsp;
            <Select
              value={subType}
              onChange={subType => {
                props.setSearchParams({subType});
                props.search();
              }}>
              {
                subTypes.map(type => {
                  return (
                    <Select.Option
                      value={type.id === -1 ? -1 : type.name}>
                      {type.name}
                    </Select.Option>
                  );
                })
              }
            </Select>
          </>
          : null
      }
      &nbsp;&nbsp;库存&nbsp;&nbsp;
      <Select
        value={stock}
        onChange={stock => {
          props.setSearchParams({stock});
          props.resetPageSearch();
        }}>
        <Select.Option value="NONE">不限</Select.Option>
        <Select.Option value="EXIST">有库存</Select.Option>
        <Select.Option value="EMPTY">无库存</Select.Option>
      </Select>
      <Button
        type="primary"
        className={styles.searchBtn}
        onClick={() => {
          props.search();
        }}>搜索</Button>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <Button
        type="primary"
        onClick={async () => {
          const
            getState = await props.getState(),
            {searchParams} = getState();
          props.reset({tabKey: searchParams.tabKey});
        }}>重置</Button>
    </div>
  );
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
  null,
  {context}
)(SearchCondition);