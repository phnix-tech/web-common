import React, {useEffect, useRef, useState} from "react";
import moment from "moment";
import {withRouter} from "react-router-dom";
import {Table} from "@alifd/next";
import PageLoading from "@/components/PageLoading";
import moneySmallToBig from "@/common/src/utils/moneySmallToBig";
import service from "@/services/warehouse";
import styles from "@/styles/print/index.module.scss";

function DataTable ({
  dataSource,
  columns,
  withTotalAmount = true,
  itemType
}) {
  let totalAmount = 0;

  dataSource.forEach(data => {
    if (data.amountOfMoney) {
      totalAmount += Number(data.amountOfMoney);
    }
  });

  if (totalAmount === 0) {
    totalAmount = "--";
  } else {
    totalAmount = totalAmount.toFixed(2);
    if (itemType === "wine") {
      totalAmount = `大写（${moneySmallToBig(Number(totalAmount))}）￥${totalAmount}`;
    } else {
      totalAmount = `￥${totalAmount}`;
    }
  }

  return (
    <div className={styles.tableWrapper}>
      <Table
        className={styles.tableBox}
        dataSource={dataSource}
        hasBorder={true}
      >
        {columns.map(item => {
          return (
            <Table.Column
              title={item.title}
              dataIndex={item.dataIndex}
              key={item.key}
              sortable={item.sortable || false}
              cell={item.cell || (value => value)}
              width={item.width || "auto"}
            />
          );
        })}
      </Table>
      {withTotalAmount ? <div className={styles.tableFooter}>合计：{totalAmount}</div> : null}
    </div>
  );
}

export default withRouter(props => {
  const
    [loading, setLoading] = useState(true),
    query = new URLSearchParams(props.location.search),
    id = query.get("id"),
    itemType = query.get("itemType") || "wine",
    cloneProps = useRef({...props, itemType});

  useEffect(() => {
    service
      .getOut(id)
      .then(item => {
        cloneProps.current.record = item;
        setLoading(false);
        setTimeout(() => {
          window.print();
          window.close();
        }, 200);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return <PageLoading/>;
  }

  if (itemType === "dining") {
    return <DiningOutStock {...cloneProps.current}/>;
  } else if (itemType === "other") {
    return <OtherOutStock {...cloneProps.current}/>;
  }

  return <WineOutStock {...cloneProps.current}/>;
});

function WineOutStock ({
  record,
  itemType
}) {
  let
    // 无折扣
    noneDiscount = true,
    // 按折扣
    byDiscount = false;

  const dataSource = record.items;
  dataSource.forEach(item => {
    byDiscount = item.displayForPrice === false;
    if (
      noneDiscount &&
      Number(item.displayPrice) !== Number(item.realPrice)
    ) {
      noneDiscount = false;
    }
  });

  const
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq",
      width: 70
    }, {
      title: "品名",
      dataIndex: "itemName",
      key: "itemName"
    }, {
      title: "规格型号",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        if (record.specification === undefined) {
          return "";
        }
        return `${record.specification.value}${record.specification.unit}`;
      }
    }, {
      title: "单位",
      dataIndex: "unit",
      key: "unit"
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count"
    }, {
      title: "全国统一零售价",
      dataIndex: "displayPrice",
      key: "displayPrice",
      width: 120
    }, ...(noneDiscount ? [] : [
      ...(byDiscount ? [{
        title: "折扣",
        dataIndex: "discount",
        key: "discount",
        cell (val, idx, record) {
          if (record.discount === undefined) {
            return "";
          }
          return record.discount.toFixed(2);
        }
      }] : []), {
        title: "折扣价",
        dataIndex: "realPrice",
        key: "realPrice",
        cell (val, idx, record) {
          if (record.realPrice === undefined) {
            return "";
          }
          return record.realPrice.toFixed(2);
        }
      }
    ]), {
      title: "小计",
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        if (record.amountOfMoney === undefined) {
          return "";
        }
        return record.amountOfMoney.toFixed(2);
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note"
    }];

  // 打印空白格子
  while (dataSource.length < 10) {
    dataSource.push({});
  }
  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  return (
    <div className={styles.container}>
      <h1>卡门大酒庄出库单</h1>
      <div className={styles.row}>
        <div className={styles.col}>
          单号：{record.uuid}
        </div>
        <div className={styles.col}>
          日期：{moment(record.date).format("YYYY-MM-DD")}
        </div>
        <div className={styles.col}>
          用途：{record.use}
        </div>
      </div>
      <div className={styles.row} style={{marginTop: 10}}>
        <div className={styles.col}>
          客户：{record.client}
        </div>
        <div className={styles.col}>
          说明：{record.note}
        </div>
        <div className={styles.col}>
          销售：{record.use === "销售" ? record.alliance : "无"}
        </div>
      </div>
      <DataTable {...{dataSource, columns, itemType}}/>
      <div className={styles.row}>
        <div className={styles.col}>
          制单人：{record.creator}
        </div>
        <div className={styles.col}>
          复核：{record.recheck}
        </div>
        <div className={styles.col}>
          提货人：{record.consignee}
        </div>
      </div>
      <div style={{marginTop: 20, color: "#aaa"}}>
        联系方式：南充市顺庆区泰和青年城21楼卡门大酒庄 0817-2166995 15892798299
      </div>
    </div>
  );
}

function DiningOutStock ({
  record,
  itemType
}) {
  const
    dataSource = record.items,
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq",
      width: 70
    }, {
      title: "品名",
      dataIndex: "itemName",
      key: "itemName"
    }, {
      title: "单位",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        return record.unit;
      }
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count"
    }, {
      title: "单价",
      dataIndex: "realPrice",
      key: "realPrice",
      cell (val, idx, record) {
        if (record.realPrice === undefined) {
          return "";
        }
        return record.realPrice.toFixed(2);
      }
    }, {
      title: "小计",
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        if (record.amountOfMoney === undefined) {
          return "";
        }
        return record.amountOfMoney.toFixed(2);
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note"
    }];

  // 打印空白格子
  while (dataSource.length < 15) {
    dataSource.push({});
  }
  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  return (
    <div className={styles.container}>
      <h1>卡门大酒庄餐饮及用品类出库单</h1>
      <div className={styles.row}>
        <div className={styles.col}>
          单号：{record.uuid}
        </div>
        <div className={styles.col}>
          日期：{moment(record.date).format("YYYY-MM-DD")}
        </div>
        <div className={styles.col}>
          领用部门：{record.use}
        </div>
        <div className={styles.col}>
          说明：{record.note}
        </div>
      </div>
      <DataTable {...{dataSource, columns, itemType}}/>
      <div className={styles.row}>
        <div className={styles.col}>
          制单人：{record.creator}
        </div>
        <div className={styles.col}>
          领用人：{record.consignee}
        </div>
        <div className={styles.col}>
          收货人：{record.consignee}
        </div>
      </div>
    </div>
  );
}

function OtherOutStock ({
  record,
  itemType
}) {
  const
    dataSource = record.items,
    columns = [{
      title: "序号",
      dataIndex: "seq",
      key: "seq",
      width: 70
    }, {
      title: "品名",
      dataIndex: "itemName",
      key: "itemName"
    }, {
      title: "单位",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        return record.unit;
      }
    }, {
      title: "数量",
      dataIndex: "count",
      key: "count"
    }, {
      title: "单价",
      dataIndex: "realPrice",
      key: "realPrice",
      cell (val, idx, record) {
        if (record.realPrice === undefined) {
          return "";
        }
        return record.realPrice.toFixed(2);
      }
    }, {
      title: "小计",
      dataIndex: "amountOfMoney",
      key: "amountOfMoney",
      cell (val, idx, record) {
        if (record.amountOfMoney === undefined) {
          return "";
        }
        return record.amountOfMoney.toFixed(2);
      }
    }, {
      title: "备注",
      dataIndex: "note",
      key: "note"
    }];

  // 打印空白格子
  while (dataSource.length < 15) {
    dataSource.push({});
  }
  dataSource.forEach((item, idx) => {
    item.seq = idx + 1;
  });

  return (
    <div className={styles.container}>
      <h1>卡门大酒庄餐饮及用品类出库单</h1>
      <div className={styles.row}>
        <div className={styles.col}>
          单号：{record.uuid}
        </div>
        <div className={styles.col}>
          日期：{moment(record.date).format("YYYY-MM-DD")}
        </div>
        <div className={styles.col}>
          领用部门：{record.use}
        </div>
        <div className={styles.col}>
          说明：{record.note}
        </div>
      </div>
      <DataTable {...{dataSource, columns, itemType}}/>
      <div className={styles.row}>
        <div className={styles.col}>
          制单人：{record.creator}
        </div>
        <div className={styles.col}>
          领用人：{record.consignee}
        </div>
        <div className={styles.col}>
          收货人：{record.consignee}
        </div>
      </div>
    </div>
  );
}