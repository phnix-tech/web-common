import searchPageStore from "@/common/src/react/stores/searchPageStore";

const
  store = searchPageStore({
    tabKey: "wine",
    name: "",
    subType: -1,
    stock: "NONE"
  }),
  {
    context,
    createStore,
    mapStateToProps,
    mapDispatchToProps
  } = store;

export {
  context,
  createStore,
  mapStateToProps,
  mapDispatchToProps
};