import React, {useEffect, useRef, useState} from "react";
import {Tab, Button, Message} from "@alifd/next";
import {connect} from "react-redux";
import stores from "@/stores/index";
import withStore from "@/common/src/react/components/withStore";
import {createStore, context, mapStateToProps, mapDispatchToProps} from "./store";
import SearchCondition from "./components/SearchCondition";
import CustomTable from "@/components/CustomTable";
import InStock from "./components/InStock";
import OutStock from "./components/OutStock";
import service from "@/services/warehouse";
import styles from "@/styles/searchpage/index.module.scss";

function pageList ({page, pageSize}, searchParams) {
  return service.getItems({
    ...searchParams,
    page,
    pageSize
  });
}

function TabContent (props) {
  const
    {tabKey} = props,
    isWine = tabKey === "wine",
    table = useRef(null),
    userProfile = stores.useStore("userProfile"),
    [selectedData] = useState(userProfile.userinfo.roleName === "管理员A" ? [] : null),
    [inStockVisible, setInStockVisible] = useState(false),
    [outStockVisible, setOutStockVisible] = useState(false);

  const columns = [
    {
      title: "名称",
      dataIndex: "itemName",
      key: "itemName"
    },
    ...(
      isWine ? [{
        title: "供应商",
        dataIndex: "supplier",
        key: "supplier"
      }] : []
    ),
    {
      title: isWine ? "规格" : "单位",
      dataIndex: "specification",
      key: "specification",
      cell (val, idx, record) {
        if (isWine) {
          // 酒类
          // 750ML * 12支
          return `${record.specification.value}${record.specification.unit}` +
            `* ${record.group.value}${record.group.unit}`;
        }

        return record.unit;
      }
    },
    ...(
      tabKey === "dining" ? [
        {
          title: "类型",
          dataIndex: "subType",
          key: "subType"
        }
      ] : []
    ),
    {
      title: "库存",
      dataIndex: "count",
      key: "count",
      cell (val, idx, record) {
        if (isWine) {
          return `${record.count}${record.unit}`;
        }

        return record.count;
      }
    }
  ];

  useEffect(() => {
    props.setState({table: table.current});
    props.setSearchParams({tabKey});
    props.search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <>
        {inStockVisible ?
          <InStock
            selectedData={selectedData}
            itemType={tabKey}
            setVisible={setInStockVisible}
            onSubmit={() => {
              props.search();
            }}
          /> : null}
        {outStockVisible ?
          <OutStock
            selectedData={selectedData}
            itemType={tabKey}
            setVisible={setOutStockVisible}
            onSubmit={() => {
              props.search();
            }}/> : null}
      </>
      <SearchCondition/>
      {
        userProfile.userinfo.roleName === "管理员A" ? (
          <div>
            <Button
              type="primary"
              onClick={() => {
                if (selectedData.length <= 0) {
                  Message.error("请选择数据");
                  return;
                } else if (selectedData.length > 15) {
                  Message.error("最多选择15项");
                  if (isWine && selectedData.length > 10) {
                    Message.error("最多选择10项");
                    return;
                  }
                  return;
                }
                setInStockVisible(true);
              }}>入库</Button>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <Button
              type="primary"
              onClick={() => {
                if (selectedData.length <= 0) {
                  Message.error("请选择数据");
                  return;
                } else if (selectedData.length > 15) {
                  if (isWine && selectedData.length > 10) {
                    Message.error("最多选择10项");
                    return;
                  }
                  Message.error("最多选择15项");
                  return;
                }
                setOutStockVisible(true);
              }}>出库</Button>
            <br/><br/>
          </div>
        ) : null
      }
      <CustomTable
        selectedData={selectedData}
        primaryKey="id"
        columns={columns}
        refs={table}
        pageList={async (...rest) => {
          const
            getState = await props.getState(),
            {searchParams} = getState();
          rest.push(searchParams);
          return pageList.apply(pageList, rest);
        }}
      />
    </>
  );
}

function TabTable () {
  const
    tabs = [
      {tab: "酒类", key: "wine"},
      {tab: "餐饮类", key: "dining"},
      {tab: "其它类", key: "other"}
    ];

  return (
    <div className={styles.container}>
      <Tab size="small" shape="wrapped">
        {tabs.map(item => {
          return (
            <Tab.Item title={item.tab} key={item.key}>
              <WithStoreTabContent tabKey={item.key}/>
            </Tab.Item>
          );
        })}
      </Tab>
    </div>
  );
}

const
  ConnectTabContent = connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {context}
  )(TabContent),
  WithStoreTabContent = withStore(ConnectTabContent, {createStore, context});

export default TabTable;