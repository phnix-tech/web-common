import React, {useEffect, useRef, useState} from "react";
import moment from "moment";
import {connect} from "react-redux";
import {Tab, Button} from "@alifd/next";
import withStore from "@/common/src/react/components/withStore";
import {context, createStore, mapDispatchToProps, mapStateToProps} from "./store";
import CustomTable from "@/components/CustomTable";
import SearchCondition from "./components/SearchCondition";
import OutStock from "../Inventory/components/OutStock";
import service from "@/services/warehouse";
import styles from "@/styles/searchpage/index.module.scss";

function pageList ({page, pageSize}, searchParams) {
  return service.getOutList({
    ...searchParams,
    page,
    pageSize
  });
}

function TabContent (props) {
  const
    {tabKey} = props,
    table = useRef(null),
    [outStockVisible, setOutStockVisible] = useState(false),
    [record, setRecord] = useState(null),

    columns = {
      wine: [
        {
          title: "单号",
          dataIndex: "uuid",
          key: "uuid",
          width: 100
        },
        {
          title: "日期",
          dataIndex: "date",
          key: "date",
          width: 100,
          cell (val, idx, record) {
            return moment(record.date).format("YYYY-MM-DD");
          }
        },
        {
          title: "金额",
          dataIndex: "amountOfMoney",
          key: "amountOfMoney",
          width: 120,
          cell (val, idx, record) {
            return record.amountOfMoney.toFixed(2);
          }
        },
        {
          title: "用途",
          dataIndex: "use",
          key: "use",
          width: 100
        },
        {
          title: "销售方",
          dataIndex: "alliance",
          key: "alliance",
          width: 150
        },
        {
          title: "客户",
          dataIndex: "client",
          key: "client",
          width: 100
        },
        {
          title: "制单人",
          dataIndex: "creator",
          key: "creator",
          width: 120
        },
        {
          title: "制单时间",
          dataIndex: "createTime",
          key: "createTime",
          width: 150
        },
        {
          title: "说明",
          dataIndex: "note",
          key: "note",
          width: 140
        },
        {
          title: "打印次数",
          dataIndex: "printCount",
          key: "printCount",
          width: 100
        },
        {
          title: "操作",
          key: "action",
          lock: "right",
          width: 200,
          cell (val, idx, record) {
            return (
              <>
                <Button
                  type="primary"
                  onClick={() => {
                    setRecord(record);
                    setOutStockVisible(true);
                  }}>
                  详情
                </Button>&nbsp;&nbsp;&nbsp;&nbsp;
                <a
                  rel="noopener noreferrer"
                  target="_blank"
                  href={
                    `${window.location.pathname}#/warehouse/stock-out/print?` +
                    `id=${record.id}&itemType=${tabKey}`
                  }>
                  <Button
                    type="primary"
                    onClick={async () => {
                      await service.updateOutPrintCount(record.id);
                      props.search();
                    }}>
                    打印
                  </Button>
                </a>
              </>
            );
          }
        }
      ],
      dining: [
        {
          title: "单号",
          dataIndex: "uuid",
          key: "uuid",
          width: 100
        },
        {
          title: "日期",
          dataIndex: "date",
          key: "date",
          width: 100,
          cell (val, idx, record) {
            return moment(record.date).format("YYYY-MM-DD");
          }
        },
        {
          title: "金额",
          dataIndex: "amountOfMoney",
          key: "amountOfMoney",
          width: 120,
          cell (val, idx, record) {
            return record.amountOfMoney.toFixed(2);
          }
        },
        {
          title: "供应商",
          dataIndex: "supplier",
          key: "supplier",
          width: 150
        },
        {
          title: "领用部门",
          dataIndex: "use",
          key: "use",
          width: 100
        },
        {
          title: "领用人",
          dataIndex: "consignee",
          key: "consignee",
          width: 100
        },
        {
          title: "制单人",
          dataIndex: "creator",
          key: "creator",
          width: 120
        },
        {
          title: "制单时间",
          dataIndex: "createTime",
          key: "createTime",
          width: 150
        },
        {
          title: "说明",
          dataIndex: "note",
          key: "note",
          width: 140
        },
        {
          title: "打印次数",
          dataIndex: "printCount",
          key: "printCount",
          width: 100
        },
        {
          title: "操作",
          key: "action",
          width: 200,
          lock: "right",
          cell (val, idx, record) {
            return (
              <>
                <Button
                  type="primary"
                  onClick={() => {
                    setRecord(record);
                    setOutStockVisible(true);
                  }}>
                  详情
                </Button>&nbsp;&nbsp;&nbsp;&nbsp;
                <a
                  rel="noopener noreferrer"
                  target="_blank"
                  href={
                    `${window.location.pathname}#/warehouse/stock-out/print?` +
                    `id=${record.id}&itemType=${tabKey}`
                  }>
                  <Button
                    type="primary"
                    onClick={async () => {
                      await service.updateOutPrintCount(record.id);
                      props.search();
                    }}>
                    打印
                  </Button>
                </a>
              </>
            );
          }
        }
      ],
      other: [
        {
          title: "单号",
          dataIndex: "uuid",
          key: "uuid",
          width: 100
        },
        {
          title: "日期",
          dataIndex: "date",
          key: "date",
          width: 100,
          cell (val, idx, record) {
            return moment(record.date).format("YYYY-MM-DD");
          }
        },
        {
          title: "金额",
          dataIndex: "amountOfMoney",
          key: "amountOfMoney",
          width: 120,
          cell (val, idx, record) {
            return record.amountOfMoney.toFixed(2);
          }
        },
        {
          title: "供应商",
          dataIndex: "supplier",
          key: "supplier",
          width: 150
        },
        {
          title: "领用部门",
          dataIndex: "use",
          key: "use",
          width: 100
        },
        {
          title: "领用人",
          dataIndex: "consignee",
          key: "consignee",
          width: 120
        },
        {
          title: "制单人",
          dataIndex: "creator",
          key: "creator",
          width: 120
        },
        {
          title: "制单时间",
          dataIndex: "createTime",
          key: "createTime",
          width: 150
        },
        {
          title: "说明",
          dataIndex: "note",
          key: "note",
          width: 140
        },
        {
          title: "打印次数",
          dataIndex: "printCount",
          key: "printCount",
          width: 100
        },
        {
          title: "操作",
          key: "action",
          width: 200,
          lock: "right",
          cell (val, idx, record) {
            return (
              <>
                <Button
                  type="primary"
                  onClick={() => {
                    setRecord(record);
                    setOutStockVisible(true);
                  }}>
                  详情
                </Button>&nbsp;&nbsp;&nbsp;&nbsp;
                <a
                  rel="noopener noreferrer"
                  target="_blank"
                  href={
                    `${window.location.pathname}#/warehouse/stock-out/print?` +
                    `id=${record.id}&itemType=${tabKey}`
                  }>
                  <Button
                    type="primary"
                    onClick={async () => {
                      await service.updateOutPrintCount(record.id);
                      props.search();
                    }}>
                    打印
                  </Button>
                </a>
              </>
            );
          }
        }
      ]
    };

  useEffect(() => {
    props.setState({table: table.current});
    props.setSearchParams({tabKey});
    props.search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <SearchCondition/>
      <CustomTable
        columns={columns[tabKey]}
        refs={table}
        pageList={async (...rest) => {
          const
            getState = await props.getState(),
            {searchParams} = getState();
          rest.push(searchParams);
          return pageList.apply(pageList, rest);
        }}
      />
      {outStockVisible ?
        <OutStock
          record={record}
          itemType={tabKey}
          setVisible={setOutStockVisible}
        /> : null}
    </>
  );
}

function TabTable () {
  const
    tabs = [
      {tab: "酒类", key: "wine"},
      {tab: "餐饮类", key: "dining"},
      {tab: "其它类", key: "other"}
    ];

  return (
    <div className={styles.container}>
      <Tab size="small" shape="wrapped">
        {tabs.map(item => {
          return (
            <Tab.Item title={item.tab} key={item.key}>
              <WithStoreTabContent tabKey={item.key}/>
            </Tab.Item>
          );
        })}
      </Tab>
    </div>
  );
}

const
  ConnectTabContent = connect(
    mapStateToProps,
    mapDispatchToProps,
    null,
    {context}
  )(TabContent),
  WithStoreTabContent = withStore(ConnectTabContent, {createStore, context});

export default TabTable;
