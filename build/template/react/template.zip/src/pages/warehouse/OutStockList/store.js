import moment from "moment";
import searchPageStore from "@/common/src/react/stores/searchPageStore";

const
  store = searchPageStore({
    tabKey: "wine",
    name: "",
    startTime: moment(moment().format("YYYY-MM-01")),
    endTime: moment()
  }),
  {
    context,
    createStore,
    mapStateToProps,
    mapDispatchToProps
  } = store;

export {
  context,
  createStore,
  mapStateToProps,
  mapDispatchToProps
};