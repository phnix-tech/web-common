import React from "react";
import {Input, Button, DatePicker} from "@alifd/next";
import {connect} from "react-redux";
import moment from "moment";
import {context, mapStateToProps, mapDispatchToProps} from "../../store";
import styles from "@/styles/searchpage/searchcondition.module.scss";

const {RangePicker} = DatePicker;

function SearchCondition (props) {
  const
    {name, startTime, endTime} = props.searchParams;

  return (
    <div className={styles.searchBox}>
      关键字&nbsp;&nbsp;
      <Input
        placeholder="输入单号、说明"
        value={name}
        onChange={name => {
          props.setSearchParams({name});
          props.resetPageSearch();
        }}/>
      &nbsp;&nbsp;日期&nbsp;&nbsp;
      <RangePicker
        value={[startTime, endTime]}
        onChange={([startTime, endTime]) => {
          props.setSearchParams({startTime, endTime});
          if (!startTime || !endTime) {
            return;
          }
          props.resetPageSearch();
        }}/>
      <Button
        type="primary"
        className={styles.searchBtn}
        onClick={() => {
          props.search();
        }}>搜索</Button>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <Button
        type="primary"
        onClick={async () => {
          const
            getState = await props.getState(),
            {searchParams} = getState();
          props.reset({
            tabKey: searchParams.tabKey,
            startTime: moment(moment().format("YYYY-MM-01")),
            endTime: moment()
          });
        }}>重置</Button>
    </div>
  );
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
  null,
  {context}
)(SearchCondition);