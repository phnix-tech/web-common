import React, {useState} from "react";
import FoundationSymbol from "@icedesign/foundation-symbol";
import {Input, Checkbox, Grid, Form, Message} from "@alifd/next";
import {useRequest} from "@/utils/request";
import {userLogin} from "@/config/dataSource";
import styles from "./index.module.scss";

const Icon = FoundationSymbol,
  {Row} = Grid,
  FormItem = Form.Item;

function Login (props) {
  const {loading, request} = useRequest(userLogin),
    [value, setValue] = useState({
      username: "",
      password: "",
      checkbox: false
    });

  function formChange (formValue) {
    setValue(formValue);
  }

  function handleSubmit (values, errors) {
    if (errors) {
      console.log("errors", errors);
      return;
    }
    handleLogin(values);
  }

  async function handleLogin (params) {
    try {
      await request({
        data: params
      });
      Message.success("登录成功");
      props.history.push("/");
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div className={styles.userLogin}>
      <div className={styles.formContainer}>
        <Form value={value} onChange={formChange}>
          <FormItem required requiredMessage="必填" className={styles.formItem}>
            <Input
              innerBefore={
                <Icon type="person" size="small" className={styles.inputIcon} />
              }
              name="username"
              maxLength={20}
              placeholder="请输入账号"
            />
          </FormItem>
          <FormItem required requiredMessage="必填" className={styles.formItem}>
            <Input
              innerBefore={
                <Icon type="lock" size="small" className={styles.inputIcon} />
              }
              name="password"
              htmlType="password"
              placeholder="请输入密码"
            />
          </FormItem>
          <FormItem>
            <Checkbox name="checkbox" className={styles.checkbox}>
              记住账号
            </Checkbox>
          </FormItem>
          <Row className={styles.formItem}>
            <Form.Submit
              type="primary"
              htmlType="submit"
              validate
              disabled={loading}
              onClick={handleSubmit}
              className={styles.submitBtn}
            >
              {loading ? "登录中..." : "登 录"}
            </Form.Submit>
          </Row>
        </Form>
      </div>
    </div>
  );
}

export default Login;
