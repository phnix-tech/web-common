import React from "react";
import {Link} from "react-router-dom";
import {injectIntl} from "react-intl";
import IceContainer from "@icedesign/container";
import styles from "./index.module.scss";

function NotFound ({intl}) {
  return (
    <div className="basic-not-found">
      <IceContainer>
        <div className={styles.exceptionContent}>
          <img
            src="https://img.alicdn.com/tfs/TB1txw7bNrI8KJjy0FpXXb5hVXa-260-260.png"
            className={styles.imgException}
            alt={intl.formatMessage({id: "app.exception.pagenotexist"})}
          />
          <div className="prompt">
            <h3 className={styles.title}>
              {intl.formatMessage({id: "app.exception.description.404"})}
            </h3>
            <p className={styles.description}>
              {intl.formatMessage({id: "app.exception.description.404.1"})}
              <Link to="/">{intl.formatMessage({id: "app.exception.description.404.2"})}</Link>
              {intl.formatMessage({id: "app.exception.description.404.3"})}
            </p>
          </div>
        </div>
      </IceContainer>
    </div>
  );
}

export default injectIntl(NotFound);