import React from "react";
import createStores from "@/common/src/react/stores/createStore";

const
  INIT_STATE = {
    dataSource: [],
    total: 0,
    loading: false,
    page: 1,
    pageSize: 10
  },
  context = React.createContext(null);

function reducer (state, action) {
  switch (action.type) {
    case "SET_STATE":
      state = {
        ...state,
        ...action.value
      };
      break;
    case "RESET":
      state = {
        ...state,
        page: INIT_STATE.page,
        pageSize: INIT_STATE.pageSize
      };
      break;
    default:
      break;
  }
  return state;
}

function createStore () {
  return createStores(reducer, INIT_STATE);
}

function mapStateToProps (state) {
  return {
    ...state
  };
}

function mapDispatchToProps (dispatch) {
  function setState (value) {
    return dispatch({
      type: "SET_STATE",
      value
    });
  }

  function search (pageList, ...rest) {
    return dispatch(async ({getState}) => {
      const
        state = getState(),
        {
          page,
          pageSize
        } = state;
      setState({loading: true});
      const {dataSource, total} = await pageList
        .apply(pageList, [{page, pageSize}, ...rest])
        .finally(() => {
          setState({loading: false});
        }) || {};

      setState({
        dataSource,
        total
      });
    });
  }

  return {
    setState,

    search,

    reset () {
      dispatch({
        type: "RESET"
      });
    }
  };
}

export {
  context,
  createStore,
  mapStateToProps,
  mapDispatchToProps
};