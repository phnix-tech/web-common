import React, {useEffect, useState} from "react";
import {Table, Pagination} from "@alifd/next";
import {connect} from "react-redux";
import withStore from "@/common/src/react/components/withStore";
import {context, createStore, mapStateToProps, mapDispatchToProps} from "./store";
import styles from "./index.module.scss";

interface TableAPI {
  search: () => any;
  // 搜索条件搜索重置页码第一页，不然UI和实际搜索条件不一致导致搜索结果显示有误
  resetPageSearch: () => any;
  reset: () => any;
}

export interface ColumnProps {
  key: string | number;
  title: string |
    React.ReactElement<any> |
    React.ReactNode |
    ((value: any, index: number, record: any) => string | React.ReactNode);
  dataIndex?: string;
  width?: string | number;
  sortable?: boolean;
  // 列锁定
  lock?: boolean | "left" | "right";
  cell?: React.ReactElement<any> |
      React.ReactNode |
      ((value: any, index: number, record: any) => string | React.ReactNode);
  // 列自定义渲染函数
  render?: React.ReactElement<any> |
    React.ReactNode |
    ((value: any, index: number, record: any) => string | React.ReactNode);
}

interface IProps {
  columns: Array<ColumnProps>;
  // 数据源接口
  pageList: () => {dataSource: Array<any>, total: number};
  // table组件对外暴露API对象
  refs?: React.MutableRefObject<TableAPI | null>;
  selectedData?: Array<any>;
  primaryKey?: string;
  style?: object;
  hasBorder?: boolean;
  // 是否显示分页，默认显示
  withPagination?: boolean;
  cellProps?: (
    rowIndex: number,
    colIndex: number,
    dataIndex: string,
    record: any
  ) => any;

  [name: string]: any;
}

function CustomTable (props: IProps) {
  const
    {
      refs,
      selectedData,
      primaryKey,
      columns = [],
      style = {},
      hasBorder = true,
      withPagination = true,
      cellProps
    } = props,
    // store state props
    {
      loading,
      total,
      dataSource,
      page,
      pageSize
    } = props;

  const [selectedRowKeys, setSelectedRowKeys] = useState<Array<string>>([]);

  useEffect(() => {
    if (refs && !refs.current) {
      refs.current = {
        search (...rest) {
          return props.search.apply(props.search, [props.pageList, ...rest]);
        },
        resetPageSearch (...rest) {
          props.setState({page: 1});
          return this.search.apply(this, rest);
        },
        reset (...rest) {
          if (selectedData) {
            selectedData.length = 0;
            setSelectedRowKeys([]);
          }
          props.reset.apply(props.reset, rest);
          return this.search();
        }
      };
    }

    return () => {
      if (refs && refs.current) {
        refs.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedData || selectedData.length <= 0) {
      return;
    }

    // 同步勾选数据
    selectedData.forEach(item => {
      const key = primaryKey as string;
      const newItem = dataSource.find((el: any) => el[key] === item[key]);
      if (newItem) {
        Object.assign(item, newItem);
      }
    });
    setSelectedRowKeys(selectedData.map(item => item[primaryKey as string]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataSource]);

  function handlePagination (page: number) {
    props.setState({page});
    props.search(props.pageList);
  }

  function handlePageSizeChange (pageSize: number) {
    props.setState({page: 1, pageSize});
    props.search(props.pageList);
  }

  function onChange (selectedRowKeys: any) {
    setSelectedRowKeys(selectedRowKeys);
  }

  function onSelect (selected: boolean, record: any) {
    const list = selectedData as Array<any>;
    const key = primaryKey as string;
    const index = list.findIndex(item => record[key] === item[key]);
    if (selected) {
      if (index === -1) {
        list.push(record);
      }
    } else if (index !== -1) {
      list.splice(index, 1);
    }
  }

  function onSelectAll (selected: boolean) {
    const list = selectedData as Array<any>;
    const key = primaryKey as string;
    dataSource.forEach((record: any) => {
      const index = list.findIndex(item => record[key] === item[key]);
      if (selected && index === -1) {
        list.push(record);
      } else if (!selected && index !== -1) {
        list.splice(index, 1);
      }
    });
  }

  const
    rowSelection = selectedData ? {
      onChange,
      onSelect,
      onSelectAll,
      selectedRowKeys,
      columnProps () {
        return {
          lock: "left",
          width: 90,
          align: "center"
        };
      },
      titleProps () {
        return {
          disabled: false,
          title: "全选"
        };
      }
    } : undefined;

  return (
    <div style={style} className={styles.container}>
      <Table
        // https://fusion.design/pc/component/basic/table#%E5%8F%AF%E9%80%89%E6%8B%A9
        rowSelection={rowSelection}
        loading={loading}
        primaryKey={primaryKey}
        dataSource={dataSource}
        hasBorder={hasBorder}
        cellProps={cellProps}
      >
        {columns.map(item => {
          if (typeof item.render === "function") {
            return (
              <Table.Column
                key={item.key}
                title={item.title}
                cell={item.render}
                width={item.width || 150}
                lock={item.lock}
              />
            );
          }

          return (
            <Table.Column
              key={item.key}
              title={item.title}
              dataIndex={item.dataIndex}
              sortable={item.sortable || false}
              cell={item.cell || ((value: any) => value)}
              width={item.width || "auto"}
              lock={item.lock}
            />
          );
        })}
      </Table>
      {
        withPagination ? (
          <Pagination
            total={total}
            totalRender={total => { return `共${total}条记录`; }}
            pageSizeSelector="dropdown"
            className={styles.pagination}
            current={page}
            pageSize={pageSize}
            pageSizePosition="end"
            pageSizeList={[10, 20, 30, 40, 50]}
            onChange={handlePagination}
            onPageSizeChange={handlePageSizeChange}
          />
        ) : null
      }
    </div>
  );
}

CustomTable.defaultProps = {
  columns: [],
  hasBorder: true,
  withPagination: true
};

const
  ConnectCustomTable = connect(
    mapStateToProps,
    mapDispatchToProps,
    // @ts-ignore
    null,
    {context}
  )(CustomTable),
  WithStoreCustomTable = withStore(ConnectCustomTable, {createStore, context});

export default WithStoreCustomTable;
