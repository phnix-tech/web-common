import React from "react";
import {createStore, combineReducers} from "redux";
import {Provider} from "react-redux";
import Index from "@/stores/reducers/Index";
import {ReactElementLike} from "prop-types";

const store: any = createStore(combineReducers({
  Index
}));

interface IProps {
  children: ReactElementLike
}

function RootStore (props: IProps) {
  const {children} = props;

  return (
    <Provider store={store}>
      {React.Children.only(children)}
    </Provider>
  );
}

export default RootStore;