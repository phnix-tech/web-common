import React from "react";
import {ReactElementLike} from "prop-types";
// https://formatjs.io/docs/react-intl
import {IntlProvider, addLocaleData} from "react-intl";
import {ConfigProvider} from "@alifd/next";
import "moment/locale/zh-cn";
// 引入 react-intl 多语言包
import zh from "react-intl/locale-data/zh";
// 引入基础组件的语言包
import zhCN from "@alifd/next/lib/locale/zh-cn";
// 引入 locale 配置文件
// eslint-disable-next-line camelcase
import zh_CN from "@/locales/zh-CN";
import {Lang} from "@/utils/locale";

// 设置语言包
addLocaleData([...zh]);

const localeInfo = {
  [Lang.zhCN]: {
    nextLocale: zhCN,
    appLocale: "zh",
    // eslint-disable-next-line camelcase
    appMessages: zh_CN
  }
};

interface Props {
  locale: Lang,
  children: ReactElementLike
}

function LocaleProvider (props: Props) {
  const {locale, children} = props;
  const myLocale = localeInfo[locale] || localeInfo[Lang.zhCN];

  return (
    <IntlProvider
      locale={myLocale.appLocale}
      messages={myLocale.appMessages}
    >
      <ConfigProvider locale={myLocale.nextLocale}>
        {React.Children.only(children)}
      </ConfigProvider>
    </IntlProvider>
  );
}

export default LocaleProvider;