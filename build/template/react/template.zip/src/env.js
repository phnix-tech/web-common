const env = require("./common/src/env");
const PUBLIC_PATH = env.PUBLIC_PATH || "/";
const BASE_URL = env.BASE_URL || "/api";

module.exports = {
  PUBLIC_PATH,
  BASE_URL
};