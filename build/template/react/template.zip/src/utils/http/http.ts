import axios, {AxiosRequestConfig, AxiosResponse} from "axios";
import cfg from "./cfg";
import {request} from "@/utils/request";

cfg.config(axios);

interface Options {
  method?: "get" | "post" | "put" | "delete" | "patch";
  url: string;
  data?: object;
  resp?: boolean;
  timeout?: number
}

function HttpRequest (
  {
    method = "get",
    url,
    data,
    resp = false,
    timeout = 10 * 1000
  }: Options
) {
  const
    // https://github.com/axios/axios
    config: AxiosRequestConfig = {
      method,
      url,
      timeout
    },
    instance = axios.create();

  cfg.addHeaders(instance);
  cfg.addTimestamp(instance);

  // 统一数据参数data
  if (data) {
    if (
      method === "put" ||
      method === "post" ||
      method === "patch"
    ) {
      config.data = data;
    } else {
      // get、delete request query params
      config.params = data;
    }
  }

  const withResp = resp;
  return new Promise((resolve, reject) => {
    request(config, instance.request)
      .then(({data, response}: {data: any, response: AxiosResponse}) => {
        if (!withResp) {
          resolve(data);
        } else {
          resolve([data, response]);
        }
      })
      .catch((e: any) => reject(e));
  });
}

export {
  HttpRequest
};