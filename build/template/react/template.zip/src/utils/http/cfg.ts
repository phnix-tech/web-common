import {AxiosInstance} from "axios";
import addUrlTimestamp from "@/common/src/utils/http/addUrlTimestamp";
import env from "@/env";

function addHeaders (axios: AxiosInstance) {
  return axios.interceptors.request.use(config => {
    // 添加全局请求头
    return config;
  });
}

function addTimestamp (axios: AxiosInstance) {
  // Add request interceptor
  return axios.interceptors.request.use(config => {
    // add timestamp to url (GET method only) for disable cache
    if (
      /^get$/i.test(config.method as string) &&
      // assume _ param is timestamp param
      !/_=\d+/.test(config.url as string)
    ) {
      config.url = addUrlTimestamp(config.url);
    }

    return config;
  });
}

function addLoginCheck (axios: AxiosInstance) {
  // http request 响应拦截器
  // https://github.com/axios/axios#interceptors
  return axios.interceptors.response.use(
    resp => resp,
    error => {
      const resp = error.response;
      if (!resp) {
        return Promise.reject(error);
      }

      if (resp.status === 401) {
        return Promise.reject(error);
      }

      return Promise.reject(error);
    }
  );
}

let isConfigured = false;

/**
 * axios common config function, e.g. add timestamp in GET url
 * @param {object} axios - axios object
 * @see https://github.com/axios/axios
 */
function config (axios: AxiosInstance) {
  if (isConfigured) {
    return;
  }

  // set global config
  axios.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded;charset=utf-8";
  // Set baseURL when debugging production url in dev mode
  axios.defaults.baseURL = env.BASE_URL;
  // 跨域传递cookie
  // https://www.cnblogs.com/nuccch/p/7875189.html
  axios.defaults.withCredentials = true;

  addHeaders(axios);
  addTimestamp(axios);

  isConfigured = true;
}

export default {
  config,
  addTimestamp,
  addHeaders,
  addLoginCheck
};
