import exception from "./exception";

export default {
  ...exception
};