const cfgOverrides = require("./src/common/build/react/config-overrides")({
  apiPrefix: process.env.API_PREFIX || undefined
});
module.exports = cfgOverrides;